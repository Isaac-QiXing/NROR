import numpy as np 

def f1(x):
    # inputs:
    #  x: a n-by-2 ndarray , each row is a sample
    # outputs:
    #  y: a 1-dim array of length n
    x1, x2 = x[:, 0], x[:, 1]
    return (5-x2)**2/(3*(5-x1)**2+(5-x2)**2)

def boha(x):
    # inputs:
    #  x: a n-by-2 ndarray , each row is a sample
    # outputs:
    #  y: a 1-dim array of length n
    # reference. https://www.sfu.ca/~ssurjano/boha.html
    x1, x2 = x[:, 0], x[:, 1]    
    return x1**2 + 2*x2**2 - 0.3* np.cos(3*np.pi*x1) - 0.4 * np.cos(4*np.pi*x2) + 0.7 

def branin(x): 
    # inputs:
    #  x: a n-by-2 ndarray , each row is a sample
    # outputs:
    #  y: a 1-dim array of length n
    # Reference. https://www.sfu.ca/~ssurjano/branin.html

    x1, x2 = x[:, 0], x[:, 1]   
    a = 1
    b = 5.1/(4*np.pi**2) 
    c = 5/np.pi
    r = 6 
    s = 10
    t = 1/(np.pi*8)
    return  a*(x2-b*x1**2 + c*x1-r)**2 + s*(1-t)*np.cos(x1) + s

def forrester(x):
    # a 1-dimensional function 
    # inputs:
    #  x: a  1-dim ndarray  of length n 
    # outputs:
    #  y: a 1-dim array of length n
    # Reference. http://www.sfu.ca/~ssurjano/forretal08.html

    return (6*x-2)**2 * np.sin(12*x-4)

def powell(x): 
    # inputs:
    #  x: a n-by-d ndarray , each row is a sample
    #      d>=4, mod(d,4) == 0
    # outputs:
    #  y: a 1-dim array of length n
    # Reference. https://www.sfu.ca/~ssurjano/powell.html

    dim = x.shape[1] # dim: number of dimensions (features)
    step = 4
    assert( dim>0 and dim %step==0 )
    ind1 = np.arange(0,dim,step)
    ind2 = np.arange(1,dim,step)
    ind3 = np.arange(2,dim,step)
    ind4 = np.arange(3,dim,step)

    x1 = x[:,ind1]
    x2 = x[:,ind2]
    x3 = x[:,ind3]
    x4 = x[:,ind4]

    return np.sum((x1 + 10*x2)**2 + 5*(x3 - x4)**2 + (x2 - 2*x3)**4 + 10*(x1 - x4)**4, axis = 1)

def levy(x):
    # inputs:
    #  x: a n-by-d ndarray , each row is a sample
    #     It's required that d>=2
    # outputs:
    #  y: a 1-dim array of length n    
    # http://www.sfu.ca/~ssurjano/levy.html
    dim = x.shape[1] # dim: number of dimensions (features)
    w = 1+ (x-1)/4
    pi = np.pi
    return np.sin(pi*w[:,0])**2 +  np.sum((w[:,0:dim]-1)**2 * (1+10*np.sin(pi*w[:,0:dim]+1)**2),axis=1) \
          + (w[:,-1]-1)**2 * (1+np.sin(2*pi*w[:,-1])**2 )

def trid(x): 
    # inputs:
    #  x: a n-by-d ndarray , each row is a sample
    #     It's required that d>=2
    # outputs:
    #  y: a 1-dim array of length n    
    # https://www.sfu.ca/~ssurjano/trid.html        

    dim = x.shape[1] # dim: number of dimensions (features)
     
    assert( dim>=2 )
    return np.sum((x-1)**2,axis=1) - np.sum(x[:,1:]*x[:,0:dim-1],axis=1)
     







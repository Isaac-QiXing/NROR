# -*- coding: utf-8 -*-
"""
Copyright 2019, SMaLL. All rights reserved.
@author:  Xi-Jun Liang, Hongyi, chen 
versions.
1st version. 2020.6
"""


import numpy as np 

def standarize(X):
    # make each column of matrix X zero-mean and unit-variance 
    if X.ndim==2:
        n,dim = X.shape
    else: #  X.ndim==1:
        n= X.size 
        dim = 1

    col_mean = X.mean(axis = 0)
    col_std = X.std(axis=0)

    if X.ndim==2:
        col_std = col_std.reshape((1,dim))
        col_std[col_std==0] = 1 # avoid the case of zero standard variance 
        return (X - col_mean.reshape((1,dim))) / col_std
    else: 
        return (X - col_mean) / col_std
        
def shuffle(X, values):
    '''
    Randomize the order of sample.

    Parameters
    ----------
    X : array-like, shape = [num_observations, num_features]
        Features of sample

    values: array-like, shape = [num_observations]
        True values for X

    Returns
    -------
    A tuple consists of X_shuffle and labels_shuffle

    X_shuffle : array, shape = [num_observations, num_features]
        The fueature matrix of sample after shuffling

    values_shuffle : array shape = [num_observations]
        The true values for X_shuffle
    '''

    randomize = np.arange(len(values))
    # Create a random order
    np.random.shuffle(randomize)
    # Shuffle original dataset
    X_shuffle = X[randomize]
    
    values_shuffle = values[randomize]
    
    return X_shuffle, values_shuffle 

def encoder(seq):
    '''
    Convert string-type label to general label 
    e.g. ['y','n','n','y'] -> [0, 1, 1, 0]
    
     Parameters
        ----------
        seq : array-like, with string elements
              the original labels
            
        Returns
        -------
        A tuple consists of encode_seq and encoder_dict
        
        encode_seq : array-like, with natural number
                     elements the label vector
                     after encoding
                     
        encoder_dict : dictionary
                     the mapping from the original
                     strings to current numbers,
                     which will be ultilized
                     by decoder.
    '''
    encoder_dict = dict(zip(set(seq),range(len(set(seq)))))
    encoded_seq = np.zeros(len(seq), dtype = 'int32')
    for i in range(len(seq)):
        encoded_seq[i] = encoder_dict[seq[i]]
    return encoded_seq, encoder_dict   
        
        
def decoder(encoded_seq, encoder_dict):
    '''
    Convert encoded sequence to original sequence
    e.g. [0, 1, 1, 0] -> ['y','n','n','y']
    
      Parameters
        ----------
        encoded_seq : array-like, with natural number elements
              the values after encoding.
        
        encoder_dict : dictionary
              the mapping from the original strings to
              current numbers.
        
        Returns
        -------
        
        decode_seq : array-like, with string elements
                     the label vector after decoding,
                     that is, the original values.
       
    
    '''
    decoder_dict = dict(zip(encoder_dict.values(),
                            encoder_dict.keys()))
    decode_seq = []
    for i in encoded_seq:
        decode_seq.append(decoder_dict[i])
    return decode_seq

def make_normalize(dat):
        for i in range(len(dat)):
            dat[i]=(dat[i]-min(dat))/(max(dat)-min(dat))
        return dat
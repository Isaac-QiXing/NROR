# -*- coding: utf-8 -*-

"""
Copyright 2019, SMaLL. All rights reserved.
@author:  Xi-Jun Liang, Hongyi Chen
versions.
1st version. 2020.6
"""

 
import numpy as np
import math
import matplotlib.pyplot as plt
import time
from kernel import Linear_Kernel, Polynomial_Kernel, RBF_Kernel
from mykernelFun import KernelFun, product_fun,initClassVar,test_initClassVar
from loss import Linear, Canal, Pseudo_Huber, Quadratic_insensitive
from qarray import QArray
#from numpy import*
import loss
 

def cal_MAPE(y_true,y_pred):
    # calculate the mean absolute percentage error (MAPE)
    # MAPE = 1/n * sum_i |(y_true[i]-y_pred[i])|/ max(epsilon,|y_true[i] |)
    
    # deal with the case that y_true[i] == 0

    epsilon = 0.1     
    diff = np.absolute((y_true-y_pred))/np.maximum(epsilon,np.absolute(y_true))
    return np.mean(diff)

class NOLRE:
    '''A Kernel-Based Noise-Resilient Online Learning Algorithm
       for Regression

    '''

    # ,MAX_NUM_SV=5000):
    def __init__(self, kernel=RBF_Kernel(), loss=Canal(), num_support_vectors=0, support_vectors=[], sample_weight=None, thresh_coef_SV=1E-5):
        '''
        Initialize the parameters of the classifier,
        including the

        kernel type:
                                                self._kernel,

        loss type:
                                                  self._loss,

        number of support vectors:
                                   self._num_support_vectors,

        collection of support vectors:
                                       self.SV,

        collection of indices of the support vectors:
                                   self._support_vectors_idx,

        number of the wrong predictions:
                                             self._num_error,

        collection of accuracies of each round:
                                              self._accuracy,

        collection of predictions of each round:
                                       self._pred_collection,

        current round:
                                          self._current_step,

        Total number of observations:
                                      self._num_observations,

        The weight of samples:
                                      self._sample_weight,

        Parameters
        ----------
        kernel : Kernel
                 An instance of Kernel object, which can be
                 ``Linear_Kernel()``, ``Polynomial_Kernel()``
                 or ``RBF_Kernel()``.
                 Default value is the ``Linear_Kernel()``.

                 NOTE: Kernel instance can be created in
                       advance or created when invoking
                       the ``__init__`` function.


        loss :   Loss
                 An instance of Loss object. The candidates
                 canbe ``Linear()`` for Linear loss, or
                 ``Canal()`` for Canal loss.
                 Default value is ``Canal()``.

        Examples
        --------
        >>> kernel = RBF_Kernel()
        >>> loss = Canal(parameter = None, policy = "adaptive")
        >>> clf = NORE(kernel, loss)
            or
        >>> clf = NOLRE(RBF_Kernel(), Canal())
        '''

        self._num_support_vectors = num_support_vectors
        if len(support_vectors) != 0:
            self.SV = support_vectors
        else:
            self.SV = []
        self._y_range = 0  # Range of the labels y, excluding outliers
        self._kernel = kernel
        self._loss = loss
        self._error = []
        self._abserror = []
        self._mape_error = []
        self._accuracy = []
        self._pred_collection = []
        self._num_observations = 0
        self._n_echo = 1
        self._current_step = 0
        self._sample_weight = sample_weight
        self.thresh_coef_SV = thresh_coef_SV
        #self.MAX_NUM_SV = MAX_NUM_SV
        self.interval_dt = {}  # information of forbidden intervals

    def get_sv(self):
        return self.SV

    def get_interval(self):
        return self.interval_dt

    def temp(self):
        print('NOLRE.temp:')
        test_initClassVar()
        print('NOLRE:KernelFun.n_sample', KernelFun.n_sample) 


    def training(self, X, y, ep, reg_coefficient, n_echo=1, n_min_train_sample = None, alpha =0.5, estimateInterval=None, seed_shuffle_X = None,initial_learning_rate = None, verbose=1):
        '''
        Train the classifier based on training dataset (X,y)      
        Parameters
        ----------
        X : array-like(generally 2D),   the observation n by p matrix,             
        y : array-like  n by 1 label vector    
        learning_rate : positive number, default 0.1
            the step size in online gradient      descent algorithm
        reg_coefficient : non-negative scalar, default 0.0
            regularization coefficient
        n_echo: number of echos for training samples    
        n_min_train_sample: minimum number of training samples; 
            if the number of samples provided by X is less than N_MIN_TRAIN_SAMPLE (if specified), 
            then the function execute multiple echoes, until the  training samples reach N_MIN_TRAIN_SAMPLE
        init : boolean, default True
            option to initialize the weight matrix, it is
            ``True`` if the classifier is trained for the first time.
            And when setting it to ``False``, the initialization of
            weight matrix should be done manually.
        estimateInterval: a KernelFun  object, to estimate the forbidden interval for each sample.
            Optional, default value: None. 
            WARNING. It is only supported for small-sized problem, 
            as the computational complexity is O(N^2), the stroge needs O(N^2), with N the number
            of training samples; 
        alpha: a scalar in (0,1)，paramteter to dynamically update the setting of delta     
        initial_learning_rate: initial learning rate
        Returns: 
        No explicit return
        '''

        debug_on = 0 #True
        period_remove_SV = 400  # period of removing samples from SVs
        # thresh_coef_SV = 1E-5 # threshold of active coefficients of SVs (others will be removed)
        flag_cal_kernelMatrix = True
        # calculate the kernel matrix beforehand, effective after setting estimateInterval

        #assert learning_rate > 0, "Error: learning rate must be positive."
        assert reg_coefficient >= 0, "Error: regularization coefficient must be non-negative."
        self._num_observations = len(y)
        self._n_echo = n_echo
        self._num_classes = len(y)  # number of samples in current batch
        self._confusion_matrix = np.nan
        self._sample_weight = np.array([])  # np.zeros(1)
        # initialize self._sample_weight
        #self._y_range = np.quantile(y, 0.95) - np.quantile(y, 0.05)
        self._y_range = np.quantile(y, 0.99) - np.quantile(y, 0.01)

        N, dim = X.shape

        MAX_NUM_SV = min(52000, max(38000, np.ceil(N*0.4)))
        periodClean = min(period_remove_SV, np.ceil(MAX_NUM_SV*0.05))
        def is_active(x): return np.fabs(x) >= self.thresh_coef_SV

        # determine the value of n_echo 
        if n_min_train_sample is not None: 
            n_echo = max(math.ceil(n_min_train_sample/N ),n_echo)

        # shuffle the order of  training  samples   
        if seed_shuffle_X is not None:     
            np.random.seed(seed_shuffle_X) # fix the random seed 
        ind = np.arange(N)
        np.random.shuffle(ind)

        # initialize self.SV
        self.SV = QArray(shape=(MAX_NUM_SV, dim), is_active=is_active, periodClean=periodClean)
        if verbose:
            print('(#sample,dim)=', N, dim)

        # calculate the kernel matrix, K, for calculating the ``forbidden interval''
        f_gold = estimateInterval
        if debug_on:
            print('NORLE.training(): f_gold, ', f_gold)
            print('NORLE.training(): estimateInterval, ',estimateInterval)
        if f_gold is not None:
            # calculate the kernel matrix beforehand
            if verbose >= 1:
                print('Estimate the forbidden intervals online.')
            #f_gold.initClassVar(X, self._kernel, flag_cal_kernelMatrix)
            if debug_on and estimateInterval is not None: 
                print('NOLRE:training-position-1' )  
                test_initClassVar()
                print('KernelFun.n_sample', KernelFun.n_sample)

            initClassVar(X, self._kernel, flag_cal_kernelMatrix)
            # calculate the elements of the kernel matrix for the traing samples
            ####
            '''
            #f_gold.test_initClassVar()
            f_gold_norm = f_gold.norm()
            print('f_gold_norm', f_gold_norm)
            print('train:KernelFun.kernelObj', KernelFun.kernelObj)
            print('train:KernelFun.n_sample', KernelFun.n_sample)
            print('train:KernelFun.kernelMatrix', KernelFun.kernelMatrix) 
            print('train:KernelFun.dim', KernelFun.dim)            
            print('f_gold.kernelObj', f_gold.kernelObj)            
            print('f_gold.kernelMatrix', f_gold.kernelMatrix)
            print('f_gold.dim', f_gold.dim)'''
            ####
        if initial_learning_rate is None:
            learning_rate0 = (1/reg_coefficient)*0.25  # inital learning rate
        else:
            learning_rate0= initial_learning_rate

        # learning_rate0=0.01
        if debug_on:
            print('learning_rate0',learning_rate0,'reg_coeff',reg_coefficient, 'alpha',alpha)
            print('kernel',self._kernel,'loss',    self._loss )

        CO_time = 0
        #f=open("20200629_WQ_50%_error.txt", "a+")
        for echo in range(n_echo):
            if verbose:
                print('echo: ',echo)
            else:
                print('=',end='')
            t_test = time.time()
            for t in range(self._num_classes):
                ite = t + self._num_classes * echo
                ii = ind[t]
                learning_rate = learning_rate0*((ite+1)**(-1/2))
                
                self._update(X[ii], y[ii], y, ite, ep, learning_rate,
                             reg_coefficient, alpha, key = ii, estimateInterval=f_gold, verbose=verbose)                      
                ###self._update(X[ii], y[ii], y, ite, ep, learning_rate,
                ###             reg_coefficient, alpha, key = None, estimateInterval=f_gold, verbose=1)
                #if  t%2000==0:
                #    print('=',end='')
            cost_tim = time.time() - t_test
        CO_time += cost_tim
        if verbose:
            print("COST TIME:{:.4}".format(CO_time))

    def _update(self, x, y, Y, t, ep, learning_rate, reg_coefficient, alpha =0.5,  key=None, estimateInterval=None, verbose=1):
        '''
        1. Predict the label given observation x based on
           the previous classifier.           
        2. Update the classifier by online gradient descent
           algorithm on the basis of current observation.   
        Parameters
        ----------
        x : array-like, 
            the observation p by 1 vector,             
        y : array-like
            true label scalar
        t: online iteration index, starts from 0    
        learning_rate : positive number
            the step size in online gradient descent algorithm
        reg_coefficient : non-negative scalar,   regularization coefficient
        key: the index of the received sample
        alpha: a scalar in (0,1)，paramteter to dynamically update the setting of delta  
        Returns:    No explicit return            
        '''

        debug_on =  0# 1#1 # 11# 0
         
        tolZero = 1E-10
        # period_remove_SV = 400 # period of removing samples from SVs
        # thresh_coef_SV = 5E-5 # threshold of active coefficients of SVs (others will be removed)

        sigma = 1 - learning_rate * reg_coefficient

        def update_weight_act(weight_act):
            return weight_act * sigma

        # 1. calculate the prediction value
        if self._num_support_vectors > 0:
            pred_value = self.predicting(x)
        else:
            pred_value = 0
            # At the beginning of training, there are no SVs, set all of the predictions to 0's.

        pred_va = pred_value
        true_va = y

        self._count_error(pred_va, true_va)
        self._count_abserror(pred_va, true_va)
        self._count_mape_error(pred_va, true_va)
        self._pred_collection.append(pred_va)

        # 2. update the  coefficients: self._sample_weight
        # 2.1 calculate the gradient
        if isinstance(self._loss, Canal):
            #grad = self._loss.grad_computing(
            #    pred_va, true_va, t, self._num_observations* self._n_echo, ep, self._y_range,alpha)
            grad = self._loss.grad_computing(
                pred_va, true_va, t, self._num_observations, ep, self._y_range,alpha)
        else:
            grad = self._loss.grad_computing(pred_va, true_va, ep)
        # print(self._loss._parameter)
        # 2.2 update self._sample_weight
        if np.fabs(grad) > tolZero:
            # set the coefficient of  current sample
            ###ind = self._num_support_vectors
            # if debug_on:
            #    print('ite',t, self._sample_weight)
                #print('ite',t, type(self._sample_weight),self._sample_weight)

            weight_current = -learning_rate * grad
            if reg_coefficient > 0 and self._current_step > 0:
                self.SV.update_y(fun=update_weight_act)
                # multiply all the weights of SVs by a constant weight
                #self._sample_weight[:self._num_support_vectors-1] *= (1 - learning_rate * reg_coefficient)

        # 2.3 update self._support_vectors
        # 2.3.1 append the current sample if it is a SV
        if np.fabs(grad) > tolZero:
            # add x and its weight to self.SV
            self.SV.add_element(x, weight_current, key,y_mode='add')
            #self.SV.add_element(x, weight_current, key,y_mode='replace')
            # y_mode='add': add the coefficient 'weight_current', if the sample has already 
            #   existed in the model
            self._num_support_vectors = sum(np.fabs(self.SV.get_act_Y()) > self.thresh_coef_SV)
        # else: np.fabs(grad) ==0, then the current sample (x,y) is directly neglected

        if debug_on:
            print('ite,pred_va,true_va:', t, pred_va, true_va)
            print('grad', grad)
            print('#act', sum(self.SV._is_act))
            coef = self.SV.get_act_Y()
            k = min(10, len(coef))
            print('#coef[:k]', coef[:k])
        if verbose >= 2 and isinstance(self._loss, Canal):
            print('t:', t, 'delta_t:', self._loss.get_parameter())

        # 2.4 update  self._accuracy
        #self._current_step += 1
        self._current_step = t
        self._accuracy.append(self._get_accuracy(self._current_step))

        # 2.5 estimate the forbidden interval
        if (estimateInterval is not None ) and isinstance(self._loss, Canal):
            # 2.5.0 initialization
            # initiate self.interval_dt
            if t == 0 or len(self.interval_dt) == 0:  # self.interval_dt is empty
                # initialization
                self.interval_dt = {'len': np.array([]),
                                    'xi_in_interval': np.array([]),
                                    't0_in_interval': np.array([]),
                                    'R_inst_sum': 0,
                                    'R_inst_sum_fgold': 0,
                                    'R_inst_ratio': np.array([])}  # dictionary of the interval information

            # 2.5.1 calculate the forbidden interval
            f_gold = estimateInterval
            norm_fgold = f_gold.norm()
            if debug_on:
                print('f_gold', f_gold)
                print('estimateInterval', estimateInterval)

            # get the coefficients of the current iterated discriminant function
            coef = self.SV.get_act_Y()
            key = self.SV.get_act_key()
            f_t = KernelFun(n_sample=f_gold.n_sample)
            f_t.setCoef(coef, key)
            ft_x = f_t.funVal(x)
            norm_ft = f_t.norm()

            if debug_on  :
                print('f_t', f_t)
                print('f_t.n_sample', f_t.n_sample)
                print('f_t.kernelMatrix', f_t.kernelMatrix)
                print('f_t.kernelObj', f_t.kernelObj)
                print('f_gold.kernelObj', f_gold.kernelObj)
                print('f_gold.n_sample', f_gold.n_sample)
                print('f_gold.kernelMatrix.size', f_gold.kernelMatrix.size)
                print('KernelFun.kernelObj', KernelFun.kernelObj)
                print('KernelFun.n_sample', KernelFun.n_sample)
                print('KernelFun.kernelMatrix', KernelFun.kernelMatrix)

            # u_t = f^t -g / |f^t - g|, g: the true discriminant function, indicated by f_gold
            u_t = f_t
            u_t.subtract(f_gold)  # u_t <- f^t -g , g: f_gole
            norm_ut = u_t.norm()
            u_t.scalarMulti(1/norm_ut)  # u_t <- (f^t -g) / |f^t - g|
            #ut_x = u_t.funVal(x) / norm_ut
            ut_x = u_t.funVal(x)

            # interval length
            len_interval = ut_x**2 / reg_coefficient
            self.interval_dt['len'] = np.append( self.interval_dt['len'], len_interval) 

            # function values of u_t and f_gold at the current sample x^t            
            f_gold_x = f_gold.funVal(x)
            if verbose >= 2:
                print('f^t(x):', ft_x, 'f_gold_x', f_gold_x, 'len_interval', len_interval)
            # 2.5.2 check whether the current sample located in the forbidden interval
            xi = ft_x - y
            delta = self._loss.get_parameter()  # delta may be adjusted adaptively
            xi_in_interval = delta - len_interval < np.abs(xi) < delta+len_interval
            self.interval_dt['xi_in_interval'] = np.append( self.interval_dt['xi_in_interval'], xi_in_interval)

            # 2.5.3 check whether t0 in Omega0
            # t0 = y - g(x_t) + u_t(x_t) * <u_t,g>
            t0 = y - f_gold_x + ut_x * product_fun(u_t, f_gold)
            t0_in_interval = delta - \
                len_interval < np.abs(t0) < delta+len_interval
            self.interval_dt['t0_in_interval'] = np.append( self.interval_dt['t0_in_interval'], t0_in_interval)

            # 2.5.4  calculate  $\frac{1}{T}\sum_{t=1}^T R_{\inst}[f^t,x_t,y_t]$, $R_{\inst}[g,S] $
            #   and the convergence ratio
            # sum_{t=1}^T R_{\inst}[f^t,x_t,y_t]
            #self.interval_dt['R_inst_sum'] += ft_x

            #loss_ft_x = self._loss.loss_computing(ft_x, y, t, self._num_observations* self._n_echo, ep, self._y_range,alpha)
            loss_ft_x = self._loss.loss_computing(ft_x, y, t, self._num_observations, ep, self._y_range,alpha)
            R_inst_ft_x = loss_ft_x + reg_coefficient * 0.5 * norm_ft**2
            self.interval_dt['R_inst_sum'] += R_inst_ft_x
            # 1/T *  R_inst_sum
            R_inst_ave = self.interval_dt['R_inst_sum']/(t+1)

            # sum_{t=1}^T R_{\inst}[f_gold,x_t,y_t]
            #self.interval_dt['R_inst_sum_fgold'] += f_gold_x
            #loss_fgold_x = self._loss.loss_computing(f_gold_x, y, t, self._num_observations* self._n_echo, ep, self._y_range,alpha)
            loss_fgold_x = self._loss.loss_computing(f_gold_x, y, t, self._num_observations, ep, self._y_range,alpha)
            R_inst_fgold_x = loss_fgold_x + reg_coefficient * 0.5 * norm_fgold**2
            self.interval_dt['R_inst_sum_fgold'] += R_inst_fgold_x
            
            R_inst_ave_fgold = self.interval_dt['R_inst_sum_fgold'] / (t + 1)
            #R_inst_ratio = np.abs(R_inst_ave - R_inst_ave_fgold)*np.sqrt(t+1)
            R_inst_ratio = (R_inst_ave - R_inst_ave_fgold)*np.sqrt(t+1)
            self.interval_dt['R_inst_ratio'] = np.append( self.interval_dt['R_inst_ratio'], R_inst_ratio)
            if verbose>=2:
                print('---t---: ',t)
                print('loss_ft_x:',loss_ft_x, 'loss_fgold_x', loss_fgold_x, \
                       'norm_ft',  norm_ft,    'norm_fgold', norm_fgold, 'R_inst_ratio',R_inst_ratio )
                print('R_inst_ft_x', R_inst_ft_x,'R_inst_fgold_x',R_inst_fgold_x ,'R_inst_ave',R_inst_ave,\
                    'R_inst_ave_fgold',R_inst_ave_fgold )
                print("self.interval_dt['R_inst_sum']",self.interval_dt['R_inst_sum'],\
                    " self.interval_dt['R_inst_sum_fgold']", self.interval_dt['R_inst_sum_fgold'])
                                                 

    def predicting(self, x):
        # Predict the value  of a new observation(s).
        # Inputs:
        #  x: a 1-dimensional array, indicating the features of a  single sample
        #    OR a 2-dimensional array with size n_sample by n_dim,
        #       indicating the feature values of a batch of samples
        # Outputs:
        #  pred_value: a real number if x is a single sample
        #       or a 1-dim array of lenght n_sample if x is a 2-dim array
        if x.ndim == 1 or x.shape[0] == 1:
            kernel_vector = self._kernel.compute_kernel(self.SV.get_act_X(), x)
            # v_i = k(x_i,x), i=1,2,...
            pred_value = np.dot(self.SV.get_act_Y(), kernel_vector)
            # .get_act_Y(): get the solved dual coefficient alpha_i for each  sample x
        else:  # x is a 2-dimensional array consisting of multiple samples
            n_sample = x.shape[0]
            pred_value = np.zeros(n_sample)
            for i in range(n_sample):
                kernel_vector = self._kernel.compute_kernel(
                    self.SV.get_act_X(), x[i, :])
                # v_i = k(x_i,x), i=1,2,...
                pred_value[i] = np.dot(self.SV.get_act_Y(), kernel_vector)
        return pred_value

    def _count_error(self, pred_value, true_value):
        '''
        Count the prediction errors at current step.
        (Internal function)

        '''
        self._error.append((pred_value-true_value)**2)
        #self._error.append(true_value-pred_value )

    def _count_abserror(self, pred_value, true_value):

        self._abserror.append(abs(true_value-pred_value))

    def _get_mae(self, t):
        return sum(self._abserror)/t

    def _count_mape_error(self, pred_value, true_value):
        if true_value == 0:
            MAPE = 0
        else:
            MAPE = np.absolute((true_value-pred_value)/true_value)
        return self._mape_error.append(MAPE)

    def _get_mape(self, t):

        return sum(self._mape_error)/(t+1)

    def _get_accuracy(self, t):
        '''
        Compute the accuracy of the classifier at step t.
        (Internal function)
        '''
        return sum(self._error)/(t+1)

    def get_num_support_vectors(self):
        # Obtain the number of support vectors.
        return self._num_support_vectors

    def get_error(self):
        '''
        Obtain total value of errors
        '''
        return sum(self._error)

    def get_accuracy(self):
        '''
        Obtain the collection of accuracies.        
        '''
        return self._accuracy

    def get_confusion_matrix(self):
        '''
        Obtain confusion matrix.        
        '''
        return self._confusion_matrix

    def get_prediction(self):
        '''
        Get all predictions so far.        
        '''
        return np.array(self._pred_collection)

    def get_num_observations(self):
        '''
        Get total number of observations so far.        
        '''
        return self._num_observations

    def get_num_classes(self):
        return self._num_classes

    def get_prediction_index(self, newx, newy):
        SSE = 0
        # SST=0
        # SSR=0
        MAE = 0
        MAPE = 0

        mean_newy = np.mean(newy)
        for i in range(len(newy)):
            pre_y = self.predicting(newx[i, :])
            SSE += (pre_y-newy[i])**2
            # SST+=(newy[i]-mean_newy)**2
            # SSR+=(pre_y-mean_newy)**2
            MAE += np.absolute(pre_y-newy[i])
            if newy[i] == 0:
                MAPE += 0
            else:
                MAPE += np.absolute((newy[i]-pre_y)/newy[i])
        RMSE =   (SSE/len(newy))**0.5 
        MAE =   MAE/len(newy) 
        MAPE =   MAPE/len(newy) 
        return ("RMSE:", RMSE, "MAE:", MAE, "MAPE:", str(MAPE*100)+'%')



    '''def get_pre_MSE(self, newx, newy):
        err = 0
        MSE = []
        for i in range(len(newy)):
            pre_y = self.predicting(newx[i, :])
            err += (pre_y-newy[i])**2
            new_mse = err/(i+1)
            # f = open("MSE.txt", "a")    # 打开文件以便写入
            # print(new_mse,file=f)
            # f.close  #  关闭文件
            MSE.append(new_mse)
        return MSE

    def get_pre_RMSE(self, newx, newy):
        err = 0
        RMSE = []
        for i in range(len(newy)):
            pre_y = self.predicting(newx[i, :])
            err += (pre_y-newy[i])**2
            new_rmse = (err/(i+1))**0.5
            # f = open("RMSE.txt", "a")    # 打开文件以便写入
            # print(new_rmse,file=f)
            # f.close  #  关闭文件
            RMSE.append(new_rmse)
        return RMSE

    def get_pre_MAE(self, newx, newy):
        err = 0
        MAE = []
        for i in range(len(newy)):
            pre_y = self.predicting(newx[i, :])
            err += abs(pre_y-newy[i])
            new_mae = err/(i+1)
            # f = open("MAE.txt", "a")    # 打开文件以便写入
            # print(new_mae,file=f)
            # f.close  #  关闭文件
            MAE.append(new_mae)
        return MAE

    def get_pre_MAPE(self, newx, newy):
        err = 0
        mean_newy = np.mean(newy)
        MAPE = []
        for i in range(len(newy)):
            pre_y = self.predicting(newx[i, :])
            if newy[i] == 0:
                err += np.absolute((newy[i]-pre_y)/mean_newy)
            else:
                err += np.absolute((newy[i]-pre_y)/newy[i])
            new_mape = err/(i+1)
            # f = open("MAPE.txt", "a")    # 打开文件以便写入
            # print(new_mape,file=f)
            # f.close  #  关闭文件
            MAPE.append(new_mape)

        return MAPE

    def plot_accuracy_curve(self, x_label="Number of samples",
                            y_label="Error"):
        #     Plot the accuracy curve, where x-axis represents the        number of samples, y-axis represents the overall
        #       accuracy from observation 1 to current observation
        # Parameters
        # x_label : string,             The name of x-axis.
        # y_label = string,       The name of y-axis.
        # Returns:  The plot of accuracy curve.            
        

        plt.plot(self._accuracy)
        plt.xlabel(x_label)
        plt.ylabel(y_label)
        plt.show()'''

'''def test_MAPE():
    n = 4
    #y_true = np.arange(n)+1
    y_true = np.arange(n)
    y_pred = np.array([2,2,3,5])
    print(y_true,y_pred)    
    print(MAPE(y_true,y_pred))

if __name__ == "__main__":
    test_MAPE()'''
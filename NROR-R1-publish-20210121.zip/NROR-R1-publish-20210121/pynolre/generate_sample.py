# generate_sample.py
# for producing sythetic samples 
import nonlinear_fun as obj
import numpy as np

# the following packages are used for testing 
import matplotlib.pyplot as plt 
from mpl_toolkits.mplot3d import Axes3D 
 

def get_default_dim(fun_name):     
# get default dimension of the specified function 
# Inputs: 
    # fun_name: string of the function name 
# Outputs:
# integer, the default dimension      
    dt = {'forrester':1 , 'f1':2,'branin':2,'boha':2,'levy':2, 'trid':2 ,'powell':4}
    # The functions levy, trid  are multi-dimensional (dim>=2)
    # The function powell has dimension >= 4
    return dt[fun_name]

def get_default_bound(fun_name,dim):     
# get default dimension of the specified function 
# Inputs: 
    # fun_name: string of the function name 
    # dim: an integer, the dimension
# Outputs:
# (lb,ut): both lb, ub are 1-dimensionl ndarray of length dim,
#  indicating the lower and upper bounds for each dimension 

   
    if fun_name == 'forrester':
        lbound =  np.zeros(dim)        
        ubound =  np.ones(dim)   # x in [0,1]        
    elif fun_name == 'f1':
        lbound = np.array([0,0])        
        ubound = np.array([10,10])   # x_i in [0,10]           
    elif fun_name == 'branin':
        lbound = np.array([-5,0])        
        ubound = np.array([10,15])
        # x_1 in [-5,10], x2 in [0,15]
    elif fun_name == 'boha':
        lbound = -100*np.ones(dim)        
        ubound = 100 * np.ones(dim)   
           # x_i in [-100,100]
    elif fun_name == 'powell':
        lbound = -4*np.ones(dim)        
        ubound = 5 * np.ones(dim) # x_i in [-4,5]
    elif fun_name == 'levy':
        lbound = -10*np.ones(dim)        
        ubound = 10 * np.ones(dim)# x_i in [-10,10]
    elif fun_name == 'trid':
        a = dim*dim
        lbound = -a*np.ones(dim)        
        ubound = a * np.ones(dim)# x_i in [-dim^2,dim^2]
    else:
        raise SystemExit('Non-supported function name.')
    return lbound,ubound

def generateXY(fun_name, n_sample, dim=None):
    # Inputs:
    # fun_name: string of the function name 
    # n_sample,dim: two positive integers, the number of samples and dimensions (features)
    # Outputs:
    # X: a n_sample-by-dim ndarray
    # Y: a 1-dimensional ndarray of length n_sample

    # check the input dimension and set the bounds for each dimension
    fun_name = fun_name.lower()
    dim_default = get_default_dim(fun_name)
    if dim is None: 
        dim = dim_default
    lbound,ubound = get_default_bound(fun_name,dim)

    '''if fun_name == 'forrester':
        if dim is not None:
            assert(dim == 1)
        else:
            dim = 1
        lbound =  np.zeros(dim)        
        ubound =  np.ones(dim)   # x in [0,1]        
    elif fun_name == 'f1':
        if dim is not None:
            assert(dim == 2)
        else:
            dim = 2
        lbound = np.array([0,0])        
        ubound = np.array([10,10])   # x_i in [0,10]           
    elif fun_name == 'branin':
        if dim is not None:
            assert(dim == 2)
        else:
            dim = 2
        lbound = np.array([-5,0])        
        ubound = np.array([10,15])
        # x_1 in [-5,10], x2 in [0,15]
    elif fun_name == 'boha':
        if dim is not None:
            assert(dim == 2)
        else:
            dim = 2
        lbound = -100*np.ones(dim)        
        ubound = 100 * np.ones(dim)   
           # x_i in [-100,100]
    elif fun_name == 'powell':
        if dim is not None:
            assert(dim >= 4)
        else:
            dim = 4
        lbound = -4*np.ones(dim)        
        ubound = 5 * np.ones(dim) # x_i in [-4,5]
    elif fun_name == 'levy':
        if dim is not None:
            assert(dim >= 2)
        else:
            dim = 2
        lbound = -10*np.ones(dim)        
        ubound = 10 * np.ones(dim)# x_i in [-10,10]
    elif fun_name == 'trid':
        if dim is not None:
            assert(dim >= 2)
        else:
            dim = 2
        a = dim*dim
        lbound = -a*np.ones(dim)        
        ubound = a * np.ones(dim)# x_i in [-dim^2,dim^2]
    else:
        raise SystemExit('Non-supported function name.')'''
    # generate X
    X = generateX(n_sample, dim, lbound, ubound)
    # generate Y
    Y = generateY(  fun_name,X)
    return (X, Y)


def generateX(n_sample, dim, lbound, ubound):
    
    X = np.random.uniform(0,1,size = (n_sample,dim))
    len_interval = ubound-lbound 
    X = X@ np.diag(len_interval) + lbound 
    return X 
    


def generateY( fun_name,X):
    # fun_name: string of the function 
    prefix = 'obj.'
    fun_name = prefix + fun_name
    fun =  eval(fun_name)
    Y = fun(X)
    Y[np.isnan(Y)] = 0 # replace NaN as 0
    return Y

def test_generateXY():
    # test generateXY()    
    # test the function powell 
    fun_name = 'powell' #'forrester' # 'trid'    
    n_sample = 3 
    X,Y = generateXY(fun_name, n_sample, dim=4)
    print(X,Y)

    # plot the functions 

    fun_name_lt = ['forrester' , 'f1','branin','boha','levy', 'trid' ] # exclude 'powell',
    n_sample = 101 
    n_fun = len(fun_name_lt)
    i_plot = 1 
    fig  = plt.figure(figsize=plt.figaspect(0.5))
    for i_fun in range(n_fun): 
        # get default dimension 
        fun_name = fun_name_lt[i_fun] 
        dim = get_default_dim(fun_name)        
        # plot the figure if dim==1 or dim == 2
        print(i_fun,dim,fun_name)

        #  0. add subplot         
        if dim==1:
            ax = fig.add_subplot(n_fun/2, 2,i_plot)
        elif dim==2:
            ax = fig.add_subplot(n_fun/2, 2,i_plot,projection = '3d')

        if dim==1:                    
            # generate x 
            x,temp = generateXY( fun_name, n_sample)
            x = x[:,0]
            x.sort()     
            # generate y        
            y = generateY(fun_name,x)
            ###print('x.shape',x.shape)
            ###print('x',x[:10],'y',y[:10])
            # plot the figure
            ax.plot(x,y)
            ax.set_title(fun_name)
            i_plot +=1
            
        elif dim==2:
             
            # 1.1 generate X data 
                # get the bounds 
            lb,ub = get_default_bound(fun_name,dim)
            delta_x = (ub[0]-lb[0])/n_sample
            delta_y = (ub[1]-lb[1])/n_sample
            x1 = np.arange(lb[0],ub[0],delta_x) # data on x1-axis
            x2 = np.arange(lb[1],ub[1],delta_y) # data on x2-axis
            X1,X2 = np.meshgrid(x1,x2)
            X11 = X1.copy()
            X22 = X2.copy() 
            # 1.2 calculate the function value 
            X1 = X1.reshape((X1.size,1))
            X2 = X2.reshape((X2.size,1))
            X = np.hstack((X1,X2))
            
            Y = generateY(fun_name,X)
            Y =  Y.reshape(X11.shape)
            ###
            #print('X',X,'Y',Y) 
            #print('X',X.shape,'X11',X11.shape,'Y',Y.shape) 
            ###
            # 2. plot the 3D-figure 
            ax.plot_surface(X11,X22,Y,cmap=plt.get_cmap('rainbow'))            
            ax.set_title(fun_name)
            # 3. 
            i_plot +=1   
    
    #fig.tight_layout()           
    plt.subplots_adjust(left=0.125,
                    bottom=0.1, 
                    right=0.9, 
                    top=0.9, 
                    wspace=0.3, 
                    hspace=0.42)
    plt.show()    
    
        


if __name__ == '__main__': test_generateXY()



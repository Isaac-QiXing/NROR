# nolre_cv.py 
# a class for cross-validation which encapsulated the interfaces of nolre 


import numpy as np
import sklearn 

from nolre1 import NOLRE
import loss 
import kernel 
from sklearn.base import BaseEstimator, ClassifierMixin
#from sklearn.linear_model import LinearRegression, LassoLarsCV, RidgeCV
#from sklearn.linear_model.base import LinearClassifierMixin, SparseCoefMixin, BaseEstimator
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
#from sklearn.metrics import classification_report, confusion_matrix 




class NROR_cv(BaseEstimator):
# kernel=RBF_Kernel(), loss=Canal()
    def __init__(self, par_reg =0.5,par_kernel = None , eta=0.5,par_canal_loss_delta = 0.5,loss=None,kernel=None,n_min_train_sample=None ):
        # initialize the parameters to be searched by Cross validation
        # the input parameter names should be identical with the class attributes
        # Inputs: 
        # par_reg: the regularization parameter 
        # eta : the initial learning rate of NROR algorithm
        # par_kernel: the kernel parameter 
        # par_canal_loss_delta: parameter, which named  alpha in the paper, 
        #   to update the canal loss parameter delta dynamically

        self.par_reg = par_reg        
        self.par_kernel  = par_kernel
        self.eta = eta 
        self.par_canal_loss_delta = par_canal_loss_delta
        # initialize other parameters 
        self.loss = loss
        self.kernel = kernel
        self.n_min_train_sample=n_min_train_sample
    #def set_kernel(self,kernelfun):
    #    self.kernel =  kernelfun       

    '''def set_par(self,loss_fun=None,kernel_fun = None ):
        # set parameters 
        if loss_fun is not None:
            self.loss = loss_fun
        if kernel_fun is not  None:
            self.kernel = kernel_fun        
        #return self '''


    def fit(self, X, Y ):
        # model training: train an online regression model 
        debug = 0
        verbose = 0# 2#0
        n_echo = 1        
        kernel_rbf = kernel.RBF_Kernel(par=self.par_kernel)   # use gaussian kernel      
        #loss_canal = loss.Canal(parameter=None, policy="adaptive")
        if debug:
            print('fit function: self.par_kernel',self.par_kernel)
            #print('fit function: loss',self.loss)
        self.clf_model = NOLRE(kernel_rbf, self.loss)        
        self.clf_model.training(X, Y, ep=0.01, reg_coefficient=self.par_reg, 
             alpha =self.par_canal_loss_delta,initial_learning_rate = self.eta,n_echo=n_echo, 
             n_min_train_sample=self.n_min_train_sample,      verbose=verbose)
        return self

    def predict(self, x):
        # predict the labels of new instances 
        # x: a 1-dimensional array, indicating the features of a  single sample
        #    OR a 2-dimensional array with size n_sample by n_dim,
        #       indicating the feature values of a batch of samples
        
        self.y_predict = self.clf_model.predicting(x)        
        return self.y_predict

    '''def get_params(self, deep=True):
        return {"n_nodes": self.n_nodes, 
                "link": self.link,
                "output_function": self.output_function,
                "n_jobs": self.n_jobs, 
                "c": self.c}

    def set_params(self, **parameters):
        for parameter, value in parameters.items():
            setattr(self, parameter, value)
        return self
    '''
def my_custom_loss_func(y_true, y_pred):
    # y_true, y_pred: vectors of the true values of y, and predicted values of y
    # truncated MAE 
    #thresh = 0.6     
    thresh = 0.4
    diff = np.abs(y_true-y_pred) 
    return np.mean(diff[diff<thresh])
    

my_score = make_scorer(my_custom_loss_func, greater_is_better=False) #needs_proba=True)


 

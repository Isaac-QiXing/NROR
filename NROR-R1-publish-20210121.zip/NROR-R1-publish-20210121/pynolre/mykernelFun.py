# -*- coding: utf-8 -*-

import numpy as np
import kernel

"""
Copyright 2019, SMaLL. All rights reserved.
@author:  Xi-Jun Liang
liangxijunsd@163.com
versions.
1st version. 2020.11

"""

__all__ = ['KernelFun', 'product_fun','initClassVar','test_initClassVar']




class KernelFun():
    # a class of kernel function
    # The functions are a set of representative functions with the following form
    #
    #       f(x) = Sum_i alpha_i * k(x_i, x)
    #  where {x_i} are fixed training samples

    X = []  # training samples, each row is a sample, each column indicates the values of a feature
    dim = 0  # number of features
    n_sample = 0  # number of samples
    kernelObj = None  # a class indicate the kernel
    kernelMatrix = None

    def __init__(self, alpha=None, n_sample=None):
        # the creating function
        # Inputs:
        #   one of the inputs, alpha or n_sample is required

        # 0. determine the value of n_sample
        assert((alpha is not None) or (n_sample is not None))
        if alpha is not None:
            KernelFun.n_sample = alpha.size
        else:
            KernelFun.n_sample = n_sample
        # 1. initiate self._alpha
        if alpha is None:
            # initiate self._alpha, it is a 1-dimensional column vector
            self._alpha = np.zeros(KernelFun.n_sample)
        else:
            self._alpha = alpha

    

    '''def initClassVar(self, X, kernel=kernel.RBF_Kernel(), flag_kernelMatrix=False,verbose=1):
        # initiate the class variables
        # Inputs:
        #  X: the  sample matrix, each row is a sample
        #  kernel: object of  the class kernel
        #  flag_kernelMatrix: True or False, whether to calcualte the kernel matrix beforehand

        KernelFun.X = X
        if KernelFun.n_sample != X.shape[0]:
            print('KernelFun.n_sample:',KernelFun.n_sample ,'X.shape[0]',X.shape[0])
        assert(KernelFun.n_sample == X.shape[0])
        KernelFun.dim = X.shape[1]
        KernelFun.kernelObj = kernel
        # calculate the kernel matrix
        if flag_kernelMatrix:
            KernelFun.kernelMatrix = kernel.kernel_matrix(X, X)
            if verbose:
                print('KernelFun.kernelMatrix has been calculated.')'''

    def setCoef(self, alpha, ind=None):
        # set the coefficients for an object of function
        # Inputs:
        #   alpha: a 1-dim Numpy array
        #       with size == KernelFun.n_sample
        #     OR size < KernelFun.n_sample, only store nonzero coefficients
        #
        #   ind: optional, a 1-dim Numpy array with the same length as alpha
        #       ind[i] indicates that  alpha[i] corresponds to the sample x[ind[i]]
        # alpha= alpha.reshape((alpha.size,1)) # ensure alpha is a TWO-dimensional column vector
        alpha = alpha.reshape(alpha.size)
        if ind is None:
            self._alpha = alpha
            if KernelFun.n_sample > 0:
                assert(alpha.size == KernelFun.n_sample)
        else:  # ind is not none
            # assert that length of ind == n_sample
            assert(ind.size == alpha.size)
            self._alpha[ind] = alpha

    def getAlpha(self):
        return self._alpha

    def funVal(self, x_new):
        # calculate the function value at a specified sample
        k_vec = KernelFun.kernelObj.compute_kernel(KernelFun.X, x_new)
        return np.dot(self._alpha, k_vec)

    def add(self, g):
        # add a representative function  f <-- f + g
        self._alpha = self._alpha + g.getAlpha()

    def subtract(self, g):
       # subtract  a function  f <-- f - g
        self._alpha = self._alpha - g.getAlpha()

    def scalarMulti(self, k):
       # subtract  a function  f <-- f *k, with k a scalar number
        self._alpha = self._alpha * k

    def norm(self):
       #
       # norm of the function |f|
        if KernelFun.kernelMatrix is not None:
            val = np.dot(self._alpha  @ KernelFun.kernelMatrix, self._alpha)
            return np.sqrt(val)
        else:
            # calculate the active kernel elements
            epsilon = 1E-8
            ind = np.abs(self._alpha) >= epsilon  # active indices
            fval = 0
            if (~ind).all():  # no active indices
                return fval
            K = KernelFun.kernelObj.kernel_matrix(KernelFun.X[ind, :], KernelFun.X[ind, :])
            alpha_act = self._alpha[ind]
            val = np.dot(alpha_act  @ K,  alpha_act)
            ###
            # print('K.shape',K.shape,'alpha_act.shape',alpha_act.shape,)
            ###
            return np.sqrt(val)

def initClassVar(X, kernel=kernel.RBF_Kernel(), flag_kernelMatrix=False, verbose=1):
    # initiate the class variables
    # Inputs:
    #  X: the  sample matrix, each row is a sample
    #  kernel: object of  the class kernel
    #  flag_kernelMatrix: True or False, whether to calcualte the kernel matrix beforehand

    KernelFun.X = X
    if KernelFun.n_sample != X.shape[0]:
        print('KernelFun.n_sample:', KernelFun.n_sample,
              'X.shape[0]', X.shape[0])
    assert(KernelFun.n_sample == X.shape[0])
    KernelFun.dim = X.shape[1]
    KernelFun.kernelObj = kernel
    # calculate the kernel matrix
    if flag_kernelMatrix:
        KernelFun.kernelMatrix = kernel.kernel_matrix(X, X)
        if verbose:
            print('KernelFun.kernelMatrix has been calculated.')

def test_initClassVar():       
        
        print('test_initClassVar:KernelFun.n_sample', KernelFun.n_sample)
        print('test_initClassVar:KernelFun.kernelObj', KernelFun.kernelObj)
        #print('test_initClassVar:self.kernelObj', self.kernelObj)

def product_fun(f, g):
    # calulate the product of two functions f and g
    # Inputs:
    #   f,g: objects of KernelFun
    # Outputs:
    #   val = <f,g>
    alpha = f.getAlpha()
    beta = g.getAlpha()
    if f.kernelMatrix is not None:
        val = np.dot(alpha  @ f.kernelMatrix, beta)
        return val
    else:
        # calculate the active kernel elements
        epsilon = 1E-8
        ind = np.abs(alpha) >= epsilon  # active indices
        ind2 = np.abs(beta) >= epsilon  # active indices
        fval = 0
        if (~ind).all():  # no active indices
            return fval
        K = f.kernelObj.kernel_matrix(f.X[ind, :], f.X[ind2, :])
        #　calculate the inner product
        val = np.dot(alpha[ind] @ K,  beta[ind2])
        return val

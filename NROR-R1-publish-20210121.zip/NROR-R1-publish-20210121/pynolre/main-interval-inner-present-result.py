# -*- coding: utf-8 -*-
# present the results for the forbidden interval

import common_excel as excel
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
import os

# parameters

debug_on = 1
flag_save2xls = 1  # whether save to excel files
flag_plot = 1  # whether plot the lines
flag_forester_only = 0# 0 #0 #1 # whether merely test forester dataset 


train_ratio = 0.5  # no. training sample / total samples
reg_coefficient = 1.0  # weight of regularization term
gauss_par = 0.6  # gaussain kernel parameters

mu_noise = 0

# ratio_noise = 0.3  # no. noisy labels / # training samples
#sigma_noise = 2

small_size = False  # True  #
if small_size:
    n_sample = 200
    #dim = 2
    verbose = 1
else:
    n_sample = 10000
    #dim = 2
    verbose = 1

# Step 0.  select a analytic 'golden' regression function f
#f0 = fun_f1

if flag_forester_only: # merely test forester dataset
    fun_name_lt = ['forrester','forrester']  # exclude 'powell',
    par_lt = [{'ratio_noise':0.7,'sigma_noise':2.0, 'alpha' : 0.5}]  
else:     
    fun_name_lt = ['forrester', 'f1', 'branin',
                   'boha', 'levy', 'trid']  # exclude 'powell',
    par_lt = [{'ratio_noise':0,  'sigma_noise':2.0,'alpha':20.0}, 
            {'ratio_noise':0.02, 'sigma_noise':2.0,'alpha': 15.0}, 
            {'ratio_noise':0.05, 'sigma_noise':2.0,'alpha': 1.0}, 
            {'ratio_noise':0.2,'sigma_noise':2.0, 'alpha' : 0.5}, 
            {'ratio_noise':0.4,'sigma_noise':2.0, 'alpha' : 0.5}, 
            {'ratio_noise':0.7,'sigma_noise':2.0, 'alpha' : 0.5}, 
            {'ratio_noise':0.4,'sigma_noise':0.3, 'alpha': 0.5}, 
            {'ratio_noise':0.4,'sigma_noise':1.0, 'alpha' : 0.5},
            {'ratio_noise':0.4,'sigma_noise':2.0, 'alpha' : 0.5},
            {'ratio_noise':0.4,'sigma_noise':4.0, 'alpha' : 0.5 }]


if flag_forester_only:
    ind_par_ratio_noise = [0,0] 
    ind_par_sigma_noise = [0,0]
else:
    ind_par_ratio_noise = [1, 2, 3, 4,5]
    #ind_par_ratio_noise = [ 5,4,3,2,1]
    #ind_par_ratio_noise = [ 1]
    ind_par_sigma_noise = [  6, 7, 8,9]


#if flag_plot:
#    ind_par_ratio_noise = [1, 2, 3, 4]
    # ind_par_ratio_noise = [ 1]



n_fun = len(fun_name_lt)
print('n_fun',n_fun)
n_par = len(par_lt)
path_result = 'result\\'

placeholder_char = '===='

#os.makedirs(path_result, exist_ok=True)

# Step 1. load and reformulate the results of various  ratio_noise
result_ratio_noise = []
result_ratio_noise_plot = []
for i_fun in range(n_fun):
    # fun name
    fun_name = fun_name_lt[i_fun]
    ratio_noise_lt = []
    interval_len_dt = {}
    r1_lt = []
    r_inst_ratio_dt = {}
    if verbose:
        print('==== i_fun', i_fun, fun_name, '======')
    for i_ind in range(len(ind_par_ratio_noise)):
        i_par = ind_par_ratio_noise[i_ind]
        # Step 1.1. load the results
        # the file name for saving the results
        file_name = 'result_' + fun_name + '_par_' + str(i_par) + '.pkl'
        result_file = path_result + file_name
        # load the variables
        with open(result_file, 'rb') as f:
            acc_train, acc_test, num_cv, interval_dt, par, file_name = pickle.load(
                f)

        # Step 1.2. re-organize the results for presentation
        if i_ind == 1:
            dataset = fun_name
        else:
            dataset = placeholder_char

        n_train = interval_dt['len'].size
        ratio_noise = par['ratio_noise']
        ave_inter_len = interval_dt['len'].mean()
        r1 = interval_dt['xi_in_interval'].mean()
        r2 = interval_dt['R_inst_ratio'][-1]  # -1:the last one
        RMSE = acc_test[1]
        MAE = acc_test[3]
        record0 = [dataset, ratio_noise,
                   ave_inter_len, r1, r2, RMSE, MAE, num_cv]
        result_ratio_noise.append(record0)
        # Step 1.3  the resutls for plot
        if flag_plot:
            # (0)  ratio_noise
            ratio_noise_lt.append(ratio_noise)
            # (1) lengths of the intervals
            interval_len_dt[str(ratio_noise)] = interval_dt['len']
            # (2) ratio of xi located in the interval
            r1_lt.append(r1)
            # (3) ratio of regret / sqrt(T)
            r_inst_ratio_dt[str(ratio_noise)] = interval_dt['R_inst_ratio']
    # end for i_ind in range(len(ind_par_ratio_noise))
    if flag_plot:        
        result_ratio_noise_plot.append(
                [dataset, ratio_noise_lt, interval_len_dt, r1_lt, r_inst_ratio_dt])


# Step 2. load and reformulate the results of various  sigma_noise
result_sigma_noise = []
result_sigma_noise_plot = []
for i_fun in range(n_fun):
    # fun name
    fun_name = fun_name_lt[i_fun]
    sigma_noise_lt = []
    interval_len_dt = {}
    r1_lt = []
    r_inst_ratio_dt = {}
    if verbose:
        print('==== i_fun', i_fun, fun_name, '======')
    for i_ind in range(len(ind_par_sigma_noise)):
        i_par = ind_par_sigma_noise[i_ind]
        # Step 1.1. load the results
        # the file name for saving the results
        file_name = 'result_' + fun_name + '_par_' + str(i_par) + '.pkl'
        result_file = path_result + file_name
        # load the variables
        with open(result_file, 'rb') as f:
            acc_train, acc_test, num_cv, interval_dt, par, file_name = pickle.load(
                f)

        # Step 1.2. re-organize the results for presentation
        if i_ind == 1:
            dataset = fun_name
        else:
            dataset = placeholder_char

        n_train = interval_dt['len'].size
        #ratio_noise = par['ratio_noise']
        sigma_noise = par['sigma_noise']
        ave_inter_len = interval_dt['len'].mean()
        r1 = interval_dt['xi_in_interval'].mean()
        r2 = interval_dt['R_inst_ratio'][-1]  # -1:the last one
        RMSE = acc_test[1]
        MAE = acc_test[3]
        record1 = [dataset, sigma_noise,
                   ave_inter_len, r1, r2, RMSE, MAE, num_cv]
        result_sigma_noise.append(record1)

        # Step 1.3  the resutls for plot
        if flag_plot:
            # (0)  sigma_noise
            sigma_noise_lt.append(sigma_noise)
            # (1) lengths of the intervals
            interval_len_dt[str(sigma_noise)] = interval_dt['len']
            # (2) ratio of xi located in the interval
            r1_lt.append(r1)
            # (3) ratio of regret / sqrt(T)
            r_inst_ratio_dt[str(sigma_noise)] = interval_dt['R_inst_ratio']

    # end for i_ind in range(len(ind_par_sigma_noise))
    if flag_plot:    
        result_sigma_noise_plot.append(
                [dataset, sigma_noise_lt, interval_len_dt, r1_lt, r_inst_ratio_dt])


# Step 3. write the results to Excels files
if flag_save2xls:
    # 3.0 sheet names and title line
    book_name_ratio_xls = 'result_forbidden_interval_ratio.xls'
    book_name_sigma_xls = 'result_forbidden_interval_sigma.xls'
    # sheet name for the two tables
    sheet_name_ratio = 'ratio_noise'
    sheet_name_sigma = 'sigma_noise'

    # title lines for the two tables
    value_title_ratio = [[placeholder_char, 'r-noise',
                          "Ave. inter. len. ", "r1", "r2", "RMSE", "MAE", "SV"]]
    value_title_sigma = [[placeholder_char, 'sigma',
                          "Ave. inter. len. ", "r1", "r2", "RMSE", "MAE", "SV"]]
    # Ave. inter. len. : average interval length
    # r1: # |{i:xi_i \in Omega_0}| / n : ratio of samples with the prediction error xi_i fallinto the forbidden interval
    # r2:  average regret / sqrt(T) : ratio of the average regret to sqrt{T}
    # RMSE: RMSE on test set
    # MAE: MAE on test set
    # #SV: number of SVs

    # 3.1 print the results about ratio_noise to xls file
    excel.write_excel_xls(book_name_ratio_xls,
                          sheet_name_ratio, value_title_ratio)
    excel.write_excel_xls_append(
        book_name_ratio_xls, sheet_name_ratio, result_ratio_noise)
    # 3.1 print the results about sigma_noise to xls file
    excel.write_excel_xls(book_name_sigma_xls,
                          sheet_name_sigma, value_title_sigma)
    excel.write_excel_xls_append(
        book_name_sigma_xls, sheet_name_sigma, result_sigma_noise)

    # excel.read_excel_xls(book_name_xls)
    print('finish to write. ')

# Step 4. depict the results in figures


def setTextDownRight(ax, text_str, fontsize0):
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    x_title = xlim[1] - (xlim[1]-xlim[0])*0.001
    y_title = ylim[0] - (ylim[1]-ylim[0])*0.10
    #x_title = xlim[1]

    #ax.text(x_title, y_title, text_str, fontsize=fontsize0,fontweight='bold',verticalalignment ='top',horizontalalignment ='right')
    ax.text(x_title, y_title, text_str, fontsize=fontsize0,
            verticalalignment='top', horizontalalignment='left')


if flag_plot:
    # 4 depict the results under various noise_ratios, and sigma_noise
    title_fun_lt = ['A', 'B', 'C', 'D', 'E', 'F']
    result_ls = [result_ratio_noise_plot, result_sigma_noise_plot]
    result_title_ls = ['ratio_noise','sigma_noise']
    x_label_ls = ['ratio of noisy labels','std. of the noise']
    fontsize0 = 6
    # plt.figure()
    plt.rcParams.update({'font.size': fontsize0, 'lines.markersize': 3, 'xtick.labelsize': fontsize0,
                         'ytick.labelsize': fontsize0, 'xtick.major.size': 1, 'xtick.minor.size': 1,
                         'ytick.major.size': 1, 'ytick.minor.size': 1,
                         'axes.titlesize': fontsize0 + 4, 'axes.labelsize': fontsize0+2})
    for i_result in range(len(result_ls)):
        figs, axes = plt.subplots(nrows=n_fun, ncols=3)
        xlabel_s = x_label_ls[i_result]
        for i_fun in range(n_fun):
            # a. get the results for one dataset (function)
            result0 = result_ls[i_result]
            record = result0[i_fun]
            dataset, ratio_noise_lt, interval_len_dt, r1_lt, r_inst_ratio_dt = record[:]
            title_fun = title_fun_lt[i_fun]

            if debug_on:
                print('dataset',dataset,'r1_lt',r1_lt,'r_inst_ratio_dt',pd.DataFrame(r_inst_ratio_dt))

            # b. depict the resutls
            # b.1 depict the interval lengths
            interval_len_df = pd.DataFrame(interval_len_dt)
            ax0 = axes[i_fun, 0]
            ax_box = interval_len_df.plot.box(ax=ax0, showfliers=False)

            # set xlael and y_label
            if i_fun == 1 or i_fun == n_fun-2:
                ax_box.set_ylabel('interval length')
            if i_fun == n_fun-1:
                ax_box.set_xlabel(xlabel_s)
            # set ylim
            ax_box.set_ylim(-0.1, 1.4)
            # set title
            title_str = '(' + title_fun + '1)'
            setTextDownRight(ax_box, title_str,  fontsize0+2)

            # b.2 depict the ratio that xi_i located in the intervals
            ax = axes[i_fun, 1]
            ax.plot(ratio_noise_lt, r1_lt, 'g', marker='o')
            # set xlael and y_label
            # if i_fun == 0 or i_fun == n_fun-1:
            #    ax.set_ylabel('ratio $r_1$')
            ax.set_ylabel('$r_1$')
            if i_fun == n_fun-1:
                ax.set_xlabel(xlabel_s)                
            # set ylim
            ax.set_ylim(0, 0.1)
            # set title
            title_str = '(' + title_fun + '2)'
            setTextDownRight(ax, title_str,  fontsize0+2)

            # b.3 depict the ratio of regret * sqrt(T)
            if i_fun == 0 or i_fun == n_fun-1:
                flag_legend = True  # whether to show the legned
            else:
                flag_legend = False
            r_inst_ratio_df = pd.DataFrame(r_inst_ratio_dt)
            ax_regret = axes[i_fun, 2]
            r_inst_ratio_df.plot(ax=ax_regret, legend=flag_legend)
            # set legned font size
            if flag_legend:
                ax_regret.legend(bbox_to_anchor=(1.02, 1.0),
                                loc='upper left', fontsize=fontsize0-2)
            # set xlael and y_label
            # if i_fun == 0 or i_fun == n_fun-1:
            #    ax_regret.set_ylabel('ratio $r_2$')
            ax_regret.set_ylabel('$r_2$')
            if i_fun == n_fun-1:
                ax_regret.set_xlabel('online iteration')
            # set ylim
            ax_regret.set_ylim(-1.0, 0.3)
            # set title
            title_str = '(' + title_fun + '3)'
            setTextDownRight(ax_regret, title_str,  fontsize0+2)

        plt.subplots_adjust(left=0.125, bottom=0.1,     right=0.9,  top=0.95,
                            wspace=0.4,  hspace=0.5)
        '''wspace and hspace specify the space reserved between subplot. 
        They are the fractions of axis width and height respectively.
        left, right, top and bottom parameters specify the positions of four sides of the subplots.
        They are the fractions of the width and height of the figure.'''
        plt.show()
        title_str  = result_title_ls[i_result] + '.png'
        figs.savefig(title_str, dpi=300)



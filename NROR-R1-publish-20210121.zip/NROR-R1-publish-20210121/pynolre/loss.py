# -*- coding: utf-8 -*- 
"""
Copyright 2019, SMaLL. All rights reserved.
@author:  Hongyi Chen，Xi-Jun Liang
@license: GPL-v3.
"""
import numpy as np
from s import loss_parameter_updating
from abc import ABCMeta, abstractmethod

#__all__ = [ 'Linear','Canal']
__all__ = [ 'Linear','Canal','Quadratic_insensitive','Pseudo_Huber']

class Loss(object):
    '''
    The abstract class for loss function
    '''
    @abstractmethod    
    def loss_computing(self, x, y):
        raise NotImplementedError('This is an abstract method')
        
    @abstractmethod
    def get_parameter(self):
        raise NotImplementedError('This is an abstract method')
    
    
class Canal(Loss):
    
    def __init__(self, parameter=None, policy = "adaptive"):
        '''
        Initialize the parameters of ramp loss.
        
        Parameters
        ----------
        parameter : number,  
                    The canal loss parameter,  delta 

                    loss_canal(e) = min(delta-epsilon,max(0,|e|-epsilon))
                    
        policy :    string, should be `adaptive` or `static`,
                    default `adaptive`
                    The strategy to choose canal loss parameter,
                    `static` stands for fixing the parameter,
                    and `adaptive` means that parameter is chosen
                    according to data.
        
        Examples
        --------
        >>> loss = Canal()
        or
        >>> loss = Canal(parameter = None, policy = "adaptive")
        or
        >>> loss = Canal(parameter = 1, policy = "static")
        '''
        self._parameter = parameter
        self._policy = policy

        assert (self._policy == "adaptive") or (self._policy == "static"),\
        "Error: the policy should be `adaptive` or `static`"
        if self._policy == "adaptive":
            assert parameter == None,\
            "Error: do not assign any value to parameter in adaptive mode"
        else:
            assert (type(parameter) == int) or (type(parameter) == float),\
            "Error: parameter should be a number"
            self._parameter = parameter
        
    def loss_computing(self, pred_value, true_value, t=0, num_observations=0, ep=0.01,y_range=1.0,alpha=0.5):
        
        '''
        Compute the Canal loss between the prediction
        of X_t and the value y_t.
        ----------
       
        '''
        if np.absolute(pred_value-true_value)<ep:
            return 0
        else:
            if self._policy == "adaptive":
                self._parameter = loss_parameter_updating(t+1,num_observations,ep,y_range,alpha)
            return   min(self._parameter - ep, max(0, abs(true_value - pred_value)-ep))
        
    def grad_computing(self, pred_value, true_value, t=0, num_observations=0, ep=0.01,y_range=1.0,alpha=0.5):
        
        '''
        Compute the gradient of the Canal loss l'(e), with e = pred_value-true_value        
        '''        
        debug_on = 0
        fun_diff = pred_value - true_value  # = f(x) - y 
        fun_diff_abs = np.absolute(fun_diff)
        if self._policy == "adaptive":
            self._parameter = loss_parameter_updating(t+1,num_observations,ep,y_range,alpha)

        if debug_on: 
            print('delta of canal loss:',self._parameter,'y_range',y_range)    
        if fun_diff_abs <ep or fun_diff_abs> self._parameter :
            return 0
        else:                          
            return   np.sign(fun_diff) 

    def get_parameter(self):
        '''
        To show the value of parameters.
        '''
        return self._parameter


class Linear(Loss):
    
    def __init__(self):
        
        self._parameter = np.inf
    
    #def loss_computing(self,true_value, pred_value, t, num_observations,ep):
    def loss_computing(self,pred_value, true_value, ep):    
        return max(0, abs(true_value - pred_value)-ep)
        

    def grad_computing(self, pred_value, true_value,ep):
        '''
        Compute the gradient of the epsilon-insensitive Linear loss l'(e), 
         with e = pred_value-true_value
        
        '''
        fun_diff = pred_value-true_value # f(x) - y
        ###fun_diff = true_value - pred_value
        fun_diff_abs = np.absolute(fun_diff)
        if fun_diff_abs <ep  :
            return 0
        else:
            return   np.sign(fun_diff) 


    def get_parameter(self):
        return self._parameter

class Quadratic_insensitive(Loss):
    
    def __init__(self):
        
        self._parameter = np.inf
    
    def loss_computing(self,pred_value, true_value,  ep):
        fun_diff = pred_value-true_value
        return max(0,fun_diff**2-ep)

    def grad_computing(self, pred_value, true_value,  ep):
        '''
        Compute the gradient of the epsilon-insensitive Quadratic loss l'(e), 
         with e = pred_value-true_value
        
        '''
        fun_diff = pred_value-true_value 
        ###fun_diff = true_value - pred_value
        fun_diff_abs = np.absolute(fun_diff)
        if fun_diff_abs < ep**0.5  :
            return 0
        else:
            return    2*fun_diff  


    def get_parameter(self):
        return self._parameter        



class Pseudo_Huber(Loss):
    
    def __init__(self,parameter = 1.0):
        
        self._parameter = parameter
    
    def loss_computing(self,pred_value, true_value,ep=0):
        fun_diff = pred_value-true_value 
        delta = self._parameter 
        return delta*delta*((1+(fun_diff/delta)**2)**0.5-1)

    def grad_computing(self, pred_value, true_value ,ep=0 ):
        '''
        Compute the gradient of the Pseudo-Huber loss l'(e), 
         with e = pred_value-true_value
        
        '''
        
        fun_diff = pred_value-true_value 
        ###fun_diff = true_value - pred_value
        delta = self._parameter
        return fun_diff/ (1+(fun_diff/delta)**2)**0.5  


    def get_parameter(self):
        return self._parameter   


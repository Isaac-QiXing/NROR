# -*- coding: utf-8 -*- 
"""
Copyright 2019, SMaLL. All rights reserved.
@author:  Xi-Jun Liang
versions.
1st version. 2020.6
"""
import numpy as np
import math 
# QArray is a class  to store paired of elements, (x,y), with limited memory
# It is based on the numpy 
    


__all__ = [ 'QArray']


class QArray():
    
    def __init__(self, shape, is_active, periodClean = np.nan ):
        '''
        Initialize the QArray.
        
        shape = a tuple of two integers or an integer, indicating the 
            maximum size of the array, 
            for instance shape  = (1000,5), 
            shape= 5000

        is_active : a function that would return whether the  indices are active, with the following format     

            ind = is_active(y)
        with 
            y: an array  
            ind:                
                 a boolean array with the length the same = len(y)
                 whether the elements corresponding to y are active 
        Examples
        --------
       
        '''
        N_MIN_ROW = 20 
        shape = list(shape)
        shape[0]= max(N_MIN_ROW,shape[0])
    
        self._nrow = shape[0] # number of rows  of ._X 
        self._X = np.zeros(shape)
        self._Y = np.zeros(self._nrow) 
        self._key = np.full(self._nrow, fill_value =-2**20,dtype =np.int32)
            # a negative fill_value -2**20 is used to distinguish the 
            #   user input key values, which are nonnegative integers 
        #self._key = np.zeros(self._nrow,dtype = np.int8)
            # an array with the same number of rows used to determine the rows to remove 
        self._is_active = is_active  
        if  np.isnan(periodClean):
            self._periodClean = max(10,math.ceil(self._nrow/10))
        else:
            self._periodClean = periodClean
        self._is_act =  np.zeros(self._nrow) >0 # active indices 
        ###self._i_current = 0 # current index of the active rows 
        self._i_receive = 0 # number of  elements (rows ) that adding to the array cumulatively 
        
        
    def add_element(self, x,y,key=None,y_mode = 'add'):        
        # add an element (row), x,  to the array self._X
        # add an element, y, to the array self._Y
        # add an element, key, to the array self._key if index is set,
        #   key: it is required that  the key value is nonnegative integer, indicating the 
        #      index of the record (x,y) 
        # y_mode: 'add' or 'replace'
        # Warning. If the specified key value has existed, then 
        #   it is required that the input x coincide with the existing record with the same key
        #   In this case, the value of y will be merged by adding the value of y of the existed 
        #       record and the input record if y_mode == 'add'; 
        #       and the value of y will be directly updated as the new input value y if y_mode =='replace'

        debug_on = 0#1
        # 0. update the record if  the key value (if specified) already exists 
        eps  = 1E-10
        if key is not None: 
            # 0.1 check whether the key value already exists 
            key_exist = self._key ==key
            flag_key_exist = key_exist.any()
            if flag_key_exist:
                ind = np.argwhere(key_exist)
                ind_key = ind[0,0]
                # 0.2 check whether the input x coincide with the existing record with the common key value
                if np.linalg.norm(self._X[ind_key] - x,ord=1)>=eps:
                    print('A common key integer is given for two different data sample.')
                # 0.3 merge or update the value of y 
                y_mode = str.lower(y_mode)
                if y_mode=='add':
                    self._Y[ind_key] += y
                else: # y_mode =='replace' 
                    self._Y[ind_key] = y
                # 0.4. update state variables 
                self._is_act[ind_key] = True
                return 

        # Otherwise, the key value (if provided) is not exist in previous records

        # 1. find an inactive indices and set as active 
        if debug_on:
            print(self._is_act,'self._is_act')
        i0 = self._is_act.argmin() 
        assert ~(self._is_act[i0]), 'None of inactive indices found'

        # 2. add elements x and y
        self._X[i0] = x
        self._Y[i0] = y
        if key is not None:
            self._key[i0] = key
        # 3. update state variables 
        self._is_act[i0] = True
        ###self._i_current +=1
        self._i_receive +=1 

        # 4. _update_act_index
        if np.fmod(self._i_receive,self._periodClean)==1:
            self._update_act_index()    

    def update_y(self, fun):
        # update the active elements of self._Y 
        if self._is_act.any():
            self._Y[self._is_act] = fun(self._Y[self._is_act])
        #self._Y = fun(self._Y)

    '''def _data_wrangling(self):
        # data wrangling with ._X, ._Y 
    '''    


    def _update_act_index(self):
        # set the active indices according to self._Y
        is_act = self._is_active(self._Y)
        self._is_act = is_act
        # check whether there exists inactive indices 
        if is_act.all(): 
            assert (~is_act).any(), "Error: the matrix has no extra space."

    def get_act_X(self):
        return self._X[self._is_act]
    
    def get_act_Y(self):
        return self._Y[self._is_act]    

    def get_act_key(self):
        return self._key[self._is_act]      

def test_qarray(n=10,d=5):
    # test Qarray()  
    import numpy as np 
    shape = (10,d)   
    def is_active(x):
         return np.fabs(x) >= 1E-10

    A = QArray(shape = shape, is_active= is_active)

    # add some records to A 
    X = np.random.rand(n,d)
    for j in range(2):# two loops 
        for i in range(n):
            A.add_element(X[i,:],y=i)
            #A.add_element(X[i,:],y=i,key = i,y_mode='add')
            #A.add_element(X[i,:],y=i,key = i,y_mode='replace')
    # print active records             
    print('act_X',A.get_act_X())
    print('act_Y',A.get_act_Y())
    print('act_key',A.get_act_key())

if __name__ == '__main__': 
    test_qarray(n=10,d=2)
    #test_qarray(n=20,d=2)



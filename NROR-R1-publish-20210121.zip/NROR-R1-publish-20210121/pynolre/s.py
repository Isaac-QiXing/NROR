# -*- coding: utf-8 -*-
"""
Copyright 2020, SMaLL. All rights reserved.
@author:  Xijun Liang
@email:   liangxijunsd@163.com
@license: GPL-v3.
"""
import numpy as np  

def loss_parameter_updating(t, num_observations,ep,y_range = 1.0,alpha = 0.5 ):
    
        '''
        Adjust the canal loss parameter adaptively.
        
        Parameters
        ----------
        t : integer, 
            Current time step
            
        num_observations : integer,
            Total number of observations
                           
        e : non-negative real number is close to zero
            
        Returns
        -------
        The value of canal loss parameter.
        
        return variable : number
            The canal loss parameter after adaptively selecting
        '''
        #alpha = 0.5 
        #b = 1 
        b= y_range
        
        #print('t',t,'num_observations',num_observations)
        '''
        assert  1 <= t <= num_observations,\
        "Error: current observation index is larger than the \
         number of observations"
        '''
        if t>=num_observations:
            num_observations = t
        
        a = -4/num_observations         
        delta=(1/(1+ np.exp(a*t-0.5)) - 0.5) * 2 * alpha *b + ep 
      

        #delta=3

        return delta

# -*- coding: utf-8 -*-
# test the method for the forbidden interval

from sklearn import preprocessing
from nolre1 import NOLRE
import kernel
import loss
import preprocess
from mykernelFun import KernelFun, test_initClassVar
from test_mykernelFun import printInf
#import pandas as pd
import math
import numpy as np
import random
#from numpy.linalg import cholesk
import matplotlib.pyplot as plt
import time
import pickle
from generate_sample import  generateXY
import os

def normalization(data):
    _range = np.max(data) - np.min(data)
    return (data - np.min(data)) / _range

# parameters
debug_on = 0 #0

flag_forester_only = 0 #11# # whether merely test forester dataset 

small_size =  False  #False#True # True #

train_ratio = 0.5  # no. training sample / total samples
reg_coefficient = 1.0  # weight of regularization term
gauss_par = 0.6  # gaussain kernel parameters
mu_noise = 0


if small_size:
    n_sample = 500   
    verbose = 0
    n_echo = 1
else:    
    n_sample = 10000
    verbose = 0
    n_echo = 1
    #n_echo = 5

# Step 0.  select a analytic 'golden' regression function f
#f0 = fun_f1

if flag_forester_only:
    fun_name_lt = ['forrester']  # exclude 'powell',
    dim_lt = [1]     
    #par_lt = [{'ratio_noise':0.02,  'sigma_noise':2.0,'alpha': 15.0}] 
    par_lt = [{'ratio_noise':0.7,'sigma_noise':2.0, 'alpha' : 0.5}]     
    #dim_lt = [1,1]
    #par_lt = [{'ratio_noise':0.05,  'sigma_noise':2.0,'alpha': 15.0},
    #          {'ratio_noise':0.2,  'sigma_noise':2.0,'alpha': 1.0}  ] 
else:
     
    fun_name_lt = ['forrester', 'f1', 'branin',   'boha', 'levy', 'trid']  # exclude 'powell',
    dim_lt = [1,2,2,2,100, 20] # dimensions of each dataset
    par_lt = [{'ratio_noise':0,  'sigma_noise':2.0,'alpha':20.0}, 
            {'ratio_noise':0.02, 'sigma_noise':2.0,'alpha': 15.0}, 
            {'ratio_noise':0.05, 'sigma_noise':2.0,'alpha': 1.0}, 
            {'ratio_noise':0.2,'sigma_noise':2.0, 'alpha' : 0.5}, 
            {'ratio_noise':0.4,'sigma_noise':2.0, 'alpha' : 0.5}, 
            {'ratio_noise':0.7,'sigma_noise':2.0, 'alpha' : 0.5}, 
            {'ratio_noise':0.4,'sigma_noise':0.3, 'alpha': 0.5}, 
            {'ratio_noise':0.4,'sigma_noise':1.0, 'alpha' : 0.5},
            {'ratio_noise':0.4,'sigma_noise':2.0, 'alpha' : 0.5},
            {'ratio_noise':0.4,'sigma_noise':4.0, 'alpha' : 0.5 }]

 # get all the testing parameter pairs

n_fun = len(fun_name_lt)
n_par = len(par_lt)
path_result =  'result\\'

os.makedirs(path_result, exist_ok=True)

for i_fun in range(n_fun):
    # Step 1 generate training and test samples without noise

    fun_name = fun_name_lt[i_fun]
    dim0 = dim_lt[i_fun]
    '''X0 = np.random.uniform(0, 10, size=(n, dim))
        Y0 = np.zeros(shape=n)
        Y0 = f0(X0)'''
    [X0, Y0] = generateXY(fun_name, n_sample, dim=dim0)
    if verbose>=0:
        print('==== i_fun',i_fun,fun_name,'dim(',dim0,')======')
    # 1.2  nomalization
    n_train = int(n_sample*train_ratio)

    my_scaler = preprocessing.MinMaxScaler()
    X0_scale = my_scaler.fit_transform(X0)
    Y0_scale = normalization(Y0)
    if debug_on:
        print("max_y:", max(Y0_scale), "min_y:", min(Y0_scale))

    # 1.3 training and testing samples
    Y0_train = np.array(Y0_scale[0:n_train])
    X0_train = np.array(X0_scale[0:n_train, :])  # train samples

    Y0_test = np.array(Y0_scale[n_train:])
    X0_test = np.array(X0_scale[n_train:, :])  # testing samples

    # Step 2.   regression with least squares min_alpha |K alpha - y|^2
    #           then  f(x) \approx g(x) = sum_i  alpha_i k(x_i,x)
    #     where the data samples (x,y) are clean (no noise)
    kernel_rbf = kernel.RBF_Kernel(par=gauss_par)
    loss_quad = loss.Quadratic_insensitive()
    clf1 = NOLRE(kernel_rbf, loss_quad)
    clf1.training(X0_train, Y0_train, ep=0.0,n_echo=1,
                  reg_coefficient=reg_coefficient, verbose=verbose)
    # epsilon = 0 : Quadratic_insensitive loss --> quadratic loss
    
    sv = clf1.get_sv()
    X0_act = sv.get_act_X()
    alpha_act = sv.get_act_Y()  # solved coefficients
    ind_act = sv.get_act_key()

    if debug_on:
        print(clf1.get_prediction_index(X0_test, Y0_test))
        print(clf1.get_num_support_vectors())
        print('clf1.sv.ind_act',ind_act)

    # Step 3. use g as a golden regression function to re-generate data samples
    #    with noise and without noise in the labels y
   
    # 3.1 get the predicted values on the training samples and test samples
    Y0_predict_train = clf1.predicting(X0_train)
    Y0_predict_test = clf1.predicting(X0_test)

    for i_par in range(n_par):

        # Step 4.1 get test parameter
        par = par_lt[i_par]
        ratio_noise = par['ratio_noise']
        sigma_noise = par['sigma_noise']
        alpha = par['alpha']
        # Step 4.2 set the file name for saving the results
        file_name = 'result_' + fun_name + '_par_' + str(i_par) + '.pkl'
        result_file = path_result + file_name
       
        # 4.3 add gaussian noises  onto the response
        n_noise = int(ratio_noise*n_train)

        np.random.seed(0)
        noise_data = np.random.normal(mu_noise, sigma_noise, n_noise)
        # Y0: the calculated response on the training samples by the regression function
        Y1 = Y0_predict_train
        Y1[0:n_noise] += noise_data
        #print("max:", max(Y1), "min:", min(Y1))

        # Step 5. online regression with canal loss and calculate the length of the ``forbidden'' interval

        loss_canal = loss.Canal(parameter=None, policy="adaptive")
        if debug_on:
            print('alpha_act.shape', alpha_act.shape,
                  'ind_act.shape:', ind_act.shape)
            print('ind_act.dtype:', ind_act.dtype)
            print('alpha_act(:10)', alpha_act[:10], 'ind_act:', ind_act[:10])
        f_gold = KernelFun(n_sample=n_train)
        f_gold.setCoef(alpha_act, ind_act)
        # set the ``best'' discriminant  function: f_gold

        if debug_on:
            print('main:f_gold.n_sample', f_gold.n_sample)
            print('main:KernelFun.n_sample', KernelFun.n_sample)
            # test_initClassVar()
            printInf()

        clf2 = NOLRE(kernel_rbf, loss_canal)
        if debug_on:
            print('main-2:f_gold.n_sample', f_gold.n_sample)
            print('main-2:KernelFun.n_sample', KernelFun.n_sample)
            # test_initClassVar()
            printInf()

         
        clf2.training(X0_train, Y1, ep=0.01, reg_coefficient=reg_coefficient,n_echo=n_echo,alpha =alpha,
                      estimateInterval=f_gold, verbose=verbose)
        interval_dt = clf2.get_interval()

        acc_train = clf2.get_prediction_index(X0_train, Y1)
        acc_test = clf2.get_prediction_index(X0_test, Y0_predict_test)
        num_cv = clf2.get_num_support_vectors()

        print('acc_train', acc_train)
        print('acc_test', acc_test)
        print('n_cv', num_cv)
        print('interval Info.', interval_dt['xi_in_interval'].sum(), interval_dt['t0_in_interval'].sum())
        # plt.plot(interval_dt['R_inst_ratio'])
        # plt.show()

        # save the variables to the files
        with open(result_file,'wb') as f:
        #f = open(result_file,'wb+')
            pickle.dump([acc_train, acc_test, num_cv, interval_dt,par,file_name], f)
        #f.close()
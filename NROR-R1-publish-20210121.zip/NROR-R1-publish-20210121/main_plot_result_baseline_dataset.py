# main_plot_result_baseline_dataset.py
#  plot the results  of MAE, RMSE on the baseline datasets

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
import matplotlib
import pickle
import os

def setTextDownRight(ax, text_str, fontsize0):
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    x_title = xlim[1] - (xlim[1]-xlim[0])*0.001
    y_title = ylim[0] - (ylim[1]-ylim[0])*0.10
    #x_title = xlim[1]

    #ax.text(x_title, y_title, text_str, fontsize=fontsize0,fontweight='bold',verticalalignment ='top',horizontalalignment ='right')
    ax.text(x_title, y_title, text_str, fontsize=fontsize0,
            verticalalignment='top', horizontalalignment='left')

flag_show_quadratic =  0  # whether plot the result of epsilon-insensitive quadratic  loss
flag_metric = 1 #0  # 0: plot MAE;   1: plot RMSE
flag_plot = 1

dataSet_lt = ['WQ', 'EGSSD', 'Abalone',
    'Cadata', 'Cpusmall', 'YearPred']  # 'f1',

path_result = 'result-cv-dell-tower\\'


fontsize = 12


frame = pd.DataFrame()
loss_lt = ['NROR', 'Linear', 'Quadratic', 'Huber']

if flag_show_quadratic:
    loss_lt_show = loss_lt
    styles = ['o-','s:','d-.','*--']
    #colors = pd.Series(['tab:orange','tab:blue','tab:brown','tab:green'])
else:
    loss_lt_show = ['NROR', 'Linear', 'Huber']
    styles = ['o-','s:','d-.']
    #colors = pd.Series(['tab:orange','tab:blue','tab:brown'],index = loss_lt_show)

#colors = colors.apply(matplotlib.colors.to_hex)

par_lt = [{'ratio_noise': 0,  'sigma_noise': 2.0},
              {'ratio_noise': 0.05, 'sigma_noise': 2.0},
              {'ratio_noise': 0.2, 'sigma_noise': 2.0},
              {'ratio_noise': 0.4, 'sigma_noise': 2.0},
              {'ratio_noise': 0.5, 'sigma_noise': 2.0},
              {'ratio_noise': 0.6, 'sigma_noise': 2.0}]
# loss_name_lt = ['NROR04', 'NROR08', 'Linear', 'Quadratic',  'Huber']
loss_name_lt = ['NROR04','NROR08', 'NROR16',  'Linear', 'Quadratic',  'Huber']
 # NROR04： delta = 0.4 for the canal loss
 # NROR08： delta = 0.8 for the canal loss
 # NROR16： delta = 1.6 for the canal loss
ind_par_ratio_noise = [0, 1, 2, 3, 4, 5]


n_par = len(par_lt)
n_loss = len(loss_name_lt)
n_dataset = len(dataSet_lt)

n_col_plot = np.int(2)
n_row_plot = math.ceil(n_dataset/n_col_plot)

print(n_col_plot,type(n_col_plot))
print(n_row_plot,type(n_row_plot))

if flag_metric == 0:
    metric_s = 'MAE'  # metric = 'MAE' or 'RMSE'
else:
    metric_s = 'RMSE' 


# set ylim for plot
if flag_metric == 0:
    ylim_lt =  [[0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5], [0, 0.5]]
else:
    ylim_lt = [[0, 0.7], [0, 0.7], [0, 0.7], [0, 0.7], [0, 0.7], [0, 0.7]]
     


# Step 1. load and reformulate the results of various  ratio_noise
result_ratio_noise = []
result_ratio_noise_plot = []
for i_data in range(n_dataset):
    # datase name
    name_data = dataSet_lt[i_data]
    # initialization
    ratio_noise_lt = []
    result_dataset_i = []

    for i_ind in range(n_par):
        # get the ratio_noise
        i_par = ind_par_ratio_noise[i_ind]
        par0 = par_lt[i_par]
        ratio_noise = par0['ratio_noise']
        ratio_noise_lt.append(ratio_noise)
        # initialization
        MAE_lt = []
        RMSE_lt = []
        MAPE_lt = []
        for i_loss in range(n_loss):
            #  set the file name for saving the results
            loss_name = loss_name_lt[i_loss]
            # Step 1.1. load the results
            # the file name for saving the results

            # file_name = 'result_' + name_data + '_par_' + str(i_par) + '_loss_' + loss_name + '.pkl'
            file_name = 'result_' + name_data + '_par_' + \
                str(ratio_noise) + '_loss_' + loss_name + '.pkl'
            sub_path = name_data + '\\result_cv\\'
            result_file = path_result + sub_path + file_name


            # load the variables
            if not os.path.exists(result_file): # check if the result file exist 
                print('Neglected the non-existed file: ' + result_file)
                continue

            with open(result_file, 'rb') as f:
                [metrics_train, metrics_test, seconds_train_test, seconds_total,
                    y_pred_train, y_pred_test, Y1_train, Y0_test, par, name_data, loss_name,
                    best_params,  file_name] = pickle.load(f)

            # Step 1.2. re-organize the results for presentation
            ratio_noise_load = par['ratio_noise']            
            assert(ratio_noise_load == ratio_noise)
            MAE = metrics_test['MAE']
            RMSE = metrics_test['RMSE']
            MAPE = metrics_test['MAPE']
            record0 = [i_data,name_data, ratio_noise_load, loss_name,
                MAE, RMSE, MAPE, seconds_train_test]
            result_ratio_noise.append(record0) 

df = pd.DataFrame(result_ratio_noise,columns=['i_data','dataset' ,'ratio', 'method',
                'MAE', 'RMSE', 'MAPE', 'seconds'])
#print(df)
#df2 = df[['i_data','dataset','ratio','method','MAE']]
#print(df2)



if flag_plot:
    # 4 depict the results under various noise_ratios, and sigma_noise
    title_fun_lt = ['A', 'B', 'C', 'D', 'E', 'F']
    
    xlabel_s = 'ratio of noisy labels'
    fontsize0 = 8
    # plt.figure()
    plt.rcParams.update({'font.size': fontsize0, 'lines.markersize': 3, 'xtick.labelsize': fontsize0,
                         'ytick.labelsize': fontsize0, 'xtick.major.size': 1, 'xtick.minor.size': 1,
                         'ytick.major.size': 1, 'ytick.minor.size': 1,
                         'axes.titlesize': fontsize0 + 4, 'axes.labelsize': fontsize0+2})
     
    figs, axes = plt.subplots(nrows=n_row_plot, ncols=n_col_plot,figsize=(6,6))
    for i_data in range(n_dataset):
        # a. get the results for one dataset
              
        title_s = title_fun_lt[i_data]
        i_row = i_data//n_col_plot # index of row for subplot 
        i_col = i_data%n_col_plot
        # get y limit 
        ylim = ylim_lt[i_data]
        # b. transform the resutls
        df1 = df[df['i_data'] == i_data]
        df2 = df1[['ratio','method',metric_s]]
        #print('df2',df2)
        df3 = df2.pivot('ratio', 'method', metric_s)

        # c. calculate the metric of NROR 
        #print(df3.columns,'type',type(print(df3.columns )) )
        index0 = pd.Index(['NROR04','NROR08', 'NROR16'])
        index1 = pd.Index.intersection(index0,df3.columns)
        
        df3['NROR'] = df3[index1].min(axis = 1)
         
        print('df3',df3)
        ax0 = axes[i_row, i_col]

        
        # set the legned 
        #if i_data == 0 or i_row == n_row_plot-1:
        flag_legend = True  # whether to show the legned

        # plot the curves 
        #df3[loss_lt_show].plot(ax=ax0, style=styles,color= colors, legend=flag_legend)
        df3[loss_lt_show].plot(ax=ax0, style=styles, legend=flag_legend)

        # plot legend
        if flag_legend:
            #ax0.legend(bbox_to_anchor=(1.02, 1.0), loc='upper left', fontsize=fontsize0-2)
            ax0.legend(loc='upper left', fontsize=fontsize0)

         # set xlael and y_label
        ax0.set_ylabel(metric_s)
        if i_row == n_row_plot-1:
            ax0.set_xlabel(xlabel_s)            
        else:
            ax0.set_xlabel('')
        # set ylim
        ax0.set_ylim(ylim)
        # add grid lines 
        ax0.grid()
        # set title
        title_str = '(' + title_s + ')'
        setTextDownRight(ax0, title_str,  fontsize0+2)

    
    plt.subplots_adjust(left=0.10, bottom=0.08,     right=0.95,  top=0.95,
                        wspace=0.22,  hspace=0.35)
    '''wspace and hspace specify the space reserved between subplot. 
        They are the fractions of axis width and height respectively.
        left, right, top and bottom parameters specify the positions of four sides of the subplots.
        They are the fractions of the width and height of the figure.'''
    
figName = 'figure/' + 'result_' + metric_s 
figs.savefig(figName +'.png',dpi = 600)
plt.show()

    

        



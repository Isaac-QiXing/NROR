# -*- coding: utf-8 -*-
# compare the performance of NROR with linear, quadratic and huber loss
#   with the parameters are chosen by cross-validation

# versions.
# 1st version. 2020.12.26
import os,sys,pickle
import numpy as np
 
 # add path of pynolre
pathBase = os.path.dirname(os.path.abspath(__file__))
path_pynolre = pathBase + '\\pynolre'
sys.path = [path_pynolre] + sys.path



from nolre_cv import NROR_cv, my_score
import sklearn.model_selection
import sklearn.metrics
from nolre1 import NOLRE, cal_MAPE
import os
from generate_sample import generateXY
import pickle
import time
import numpy as np
import loss
import kernel
from sklearn import preprocessing
import os
import sys
pathBase = os.path.dirname(os.path.abspath(__file__))

path_pynolre = pathBase + '\\pynolre'
sys.path = [path_pynolre] + sys.path

# import preprocess
# from mykernelFun import KernelFun, test_initClassVar
# from test_mykernelFun import printInf
# import pandas as pd
# import random
# from numpy.linalg import cholesk


def normalization(data):
    _range = np.max(data) - np.min(data)
    return (data - np.min(data)) / _range


def get_metrics(y_true, y_pred):
    # get the metrics of the errors

    MAE = sklearn.metrics.mean_absolute_error(y_true, y_pred)
    MSE = sklearn.metrics.mean_squared_error(y_true, y_pred)
    RMSE = MSE**0.5

    # MAPE = sklearn.metrics.mean_absolute_percentage_error(y_true,y_pred)
    MAPE = cal_MAPE(y_true, y_pred)
    d = {'MAE': MAE, 'RMSE': RMSE, 'MAPE': MAPE}
    return d

# 0 . parameters
# debug_on = 0  # 0


small_size = True  #False # False # True # False  #  trying to run the code quickly, with small size and a few groups of parameters

mu_noise = 0
debug = 0
flag_prediction = 1 # whether calculate prediction accuracies on the training and test datasets 
flag_CV_only_NROR =  False #1 #0 
    # 1: merely choose the parameter values of NROR by Cross-validation 
    # 0: choose the parameter values of all baseline methods, NROR, linear, Quadratic and huber, by Cross-validation 



if small_size:
    train_ratio = 0.4  # no. training sample / total samples
    #n_sample_f1 = 10000
    #n_sample_cv = 5000  # maximum number of training samples for cross-validation
    n_sample_f1 = 5000
    n_sample_cv = 5000  # maximum number of training samples for cross-validation   
    
    k_fold = 2
    verbose = 0
   
    
else:
    train_ratio = 0.5  # no. training sample / total samples
    n_sample_f1 = 10000
    n_sample_cv = 5000  # maximum number of training samples for cross-validation
    k_fold = 3
    verbose = 0


n_echo_train = 1 # number of (minimum) epochs for training 
    

# set the loss functions
# loss_canal = loss.Canal(parameter=None, policy="adaptive")
loss_canal_delta04 = loss.Canal(parameter=0.4, policy="static")
loss_canal_delta08 = loss.Canal(parameter=0.8, policy="static")
loss_canal_delta16 = loss.Canal(parameter=1.6, policy="static")
loss_canal = loss_canal_delta16
loss_linear = loss.Linear()
loss_quad = loss.Quadratic_insensitive()
loss_huber = loss.Pseudo_Huber()

if small_size:
    #name_data_lt = ['f1']
    #name_data_lt = ['WQ']
    name_data_lt = ['YearPred']
    #name_data_lt = ['Cpusmall']
    #name_data_lt = ['Abalone']
    
    # dim_lt = [2]
    # name_data_lt = ['f1', 'WQ','EGSSD','Abalone','Cadata','Cpusmall','YearPred']
    #loss_name_lt = ['NROR16']
    #loss_lt = [loss_canal_delta16]
    #loss_name_lt = ['NROR','Linear']
    #loss_lt = [loss_canal,loss_linear]
    #loss_name_lt = ['NROR04', 'NROR08', 'Linear', 'Quadratic',  'Huber']  # NROR employs the canal loss
    #loss_lt = [loss_canal_delta04, loss_canal_delta08, loss_linear, loss_quad,   loss_huber]  # the loss functions
      
    #n_min_train_sample = 200

    # loss_name_lt = ['NROR', 'Linear', 'Quadratic',  'Huber']  # NROR employs the canal loss
    # loss_lt = [loss_canal, loss_linear, loss_quad, loss_huber]  # the loss functions
    loss_name_lt = ['Linear',  'Huber']  # NROR employs the canal loss
    loss_lt = [ loss_linear, loss_huber]  # the loss functions
    #par_lt = [{'ratio_noise': 0.05, 'sigma_noise': 2.0}]
    #par_lt = [{'ratio_noise': 0.00, 'sigma_noise': 2.0}]
    par_lt = [{'ratio_noise': 0.2, 'sigma_noise': 2.0},
              {'ratio_noise': 0.5, 'sigma_noise': 2.0}]
    '''par_lt = [{'ratio_noise': 0,  'sigma_noise': 2.0},
              {'ratio_noise': 0.05, 'sigma_noise': 2.0},
              {'ratio_noise': 0.2, 'sigma_noise': 2.0},
              {'ratio_noise': 0.4, 'sigma_noise': 2.0},
              {'ratio_noise': 0.5, 'sigma_noise': 2.0},
              {'ratio_noise': 0.6, 'sigma_noise': 2.0}]  '''        
    '''param_grid = {'par_reg': [0.1],
                  'par_kernel': [0.5, 16.0],
                  'eta': [0.1]}'''
    param_grid = {'par_reg': [0.1, 0.04],
                  'par_kernel': [0.5, 2.0, 8.0, 32.0],
                  'eta': [0.5, 0.1]}             
                
    n_min_train_sample = 5000
    n_min_train_sample_cv = 5000
    '''param_grid={'par_reg':[  0.1  ],
                'par_kernel' : [ 4.0,16.0],
                'eta':[0.2,0.5] }'''
    '''param_grid={'par_reg':[  0.02   ],
                'par_kernel' : [ 8.0,32.0],
                'eta':[1.0,3.0] } '''

    '''param_grid = {'par_reg': [0.5, 0.2, 0.05],
                  'par_kernel': [8.0, 32.0],
                  'eta': [1.0, 0.5]}'''
else:

    name_data_lt = ['YearPred' ]
    #name_data_lt = ['f1', 'WQ', 'EGSSD', 'Abalone',  'Cadata', 'Cpusmall', 'YearPred']
    par_lt = [{'ratio_noise': 0,  'sigma_noise': 2.0},
              {'ratio_noise': 0.05, 'sigma_noise': 2.0},
              {'ratio_noise': 0.2, 'sigma_noise': 2.0},
              {'ratio_noise': 0.4, 'sigma_noise': 2.0},
              {'ratio_noise': 0.5, 'sigma_noise': 2.0},
              {'ratio_noise': 0.6, 'sigma_noise': 2.0}]
    '''param_grid = {'par_reg': [0.4,  1.0],
                  'par_kernel': [0.2, 0.6, 2.0, 8.0],
                  'eta': [0.05, 0.5]}  # 'par_canal_loss_delta': corresponds to the value of alpha'''
    param_grid = {'par_reg': [0.1, 0.04],
                  'par_kernel': [0.5, 2.0, 8.0, 32.0],
                  'eta': [0.5, 0.1]}              
    loss_name_lt = ['NROR16']  
    loss_lt = [loss_canal_delta16]  # the loss functions
    #loss_name_lt = ['NROR04', 'NROR08', 'Linear', 'Quadratic',  'Huber']  # NROR employs the canal loss
    #loss_lt = [loss_canal_delta04, loss_canal_delta08, loss_linear, loss_quad,   loss_huber]  # the loss functions
    n_min_train_sample = 5000
    n_min_train_sample_cv = 5000  # minimum number of training samples for cross validation 

n_loss = len(loss_lt)
n_fun = len(name_data_lt)
n_par = len(par_lt)
#path_result0 = 'result_cv\\'  
path_result = 'result_cv\\' 
dataPath = pathBase + '\\dataset\\'

#print('n_loss',n_loss)

os.makedirs(path_result, exist_ok=True)


for i_fun in range(n_fun):
    # Step 1 generate training and test samples
    # 1.1 generate clean samples
    
    name_data = name_data_lt[i_fun]

    if name_data == 'f1':
        n_dim_f1 = 2
        [X0, Y0] = generateXY(name_data, n_sample_f1, dim=n_dim_f1)
        n_sample, n_dim = X0.shape
    else:
        output_file = dataPath + name_data + '.pkl'
        with open(output_file, 'rb') as f:
            [X0, Y0, n_sample, n_dim] = pickle.load(f)
    print('dataset:', name_data, 'shape', n_sample, n_dim)
    # 1.2  nomalization

    my_scaler = preprocessing.MinMaxScaler()
    X0_scale = my_scaler.fit_transform(X0)
    Y0_scale = normalization(Y0)
    # 1.3 shuffle the samples and its labels
    ind = np.arange(n_sample)
    np.random.shuffle(ind)
    if debug:
        print('ind', ind)
    X0_scale = X0_scale[ind, :]
    Y0_scale = Y0_scale[ind]

    # 1.3 generate training and testing samples
    # 1.3.1 split the set
    n_train = int(n_sample*train_ratio)
    n_cv = min(n_sample_cv, n_train)  # number of samples for cross-validation
    Y0_train = np.array(Y0_scale[0:n_train])
    X0_train = np.array(X0_scale[0:n_train, :])  # train samples
    Y0_cv = np.array(Y0_scale[0:n_cv])
    X0_cv = np.array(X0_scale[0:n_cv, :])  # samples for cross validation
    Y0_test = np.array(Y0_scale[n_train:])
    X0_test = np.array(X0_scale[n_train:, :])  # testing samples

    for i_par in range(n_par):  # various ratios of noisy labels and std.

        # 1.3.2 add gaussian noises  onto the response   Y0_train
        #  get test parameter
        par = par_lt[i_par]
        ratio_noise = par['ratio_noise']
        sigma_noise = par['sigma_noise']
        # alpha = par['alpha']
        n_noise = int(ratio_noise*n_train)
        Y1_train = Y0_train
        if n_noise > 0:
            np.random.seed(0)
            noise_data = np.random.normal(mu_noise, sigma_noise, n_noise)
            # Y0: the calculated response on the training samples by the regression function
            Y1_train[0:n_noise] += noise_data
        Y1_cv = Y1_train[0:n_cv]  # note that n_cv <= n_noise

        # Step 2.   online regression by the baseline methods (loss functions) with cross-validation

        # 2.1 cross-validation to determine the parameters
        if flag_CV_only_NROR: 
            t1 = time.perf_counter()
            model = NROR_cv(loss=loss_canal,n_min_train_sample = n_min_train_sample_cv)
            gs = sklearn.model_selection.GridSearchCV(model, cv=k_fold, param_grid=param_grid, scoring=my_score)
            gs.fit(X0_cv, Y1_cv)
            t2 = time.perf_counter()
            seconds_cv = t2-t1
            print('cv: best par:', gs.best_params_)


        for i_loss in range(n_loss):
            #  set the file name for saving the results
            loss_fun = loss_lt[i_loss]
            loss_name = loss_name_lt[i_loss]
            print('---', name_data, '\t i_par: ', i_par, loss_name, '---')

            #file_name = 'result_' + name_data + '_par_' + str(i_par) + '_loss_' + loss_name + '.pkl'
            file_name = 'result_' + name_data + '_par_' + str(ratio_noise) + '_loss_' + loss_name + '.pkl'
            result_file = path_result + file_name

            # 2.1 cross-validation to determine the parameters for each baseline method 
            if not flag_CV_only_NROR: 
                t1 = time.perf_counter()
                model = NROR_cv(loss=loss_fun,n_min_train_sample = n_min_train_sample_cv)      
                gs = sklearn.model_selection.GridSearchCV(model, cv=k_fold, param_grid=param_grid, scoring=my_score)
                gs.fit(X0_cv,Y1_cv)
                t2 = time.perf_counter()
                seconds_cv = t2-t1
                print('cv: best par:',gs.best_params_,'seconds',seconds_cv)

            # 2.2 train the model again with the selected ``best'' parameter
            par_best = gs.best_params_
            kernel_rbf_train = kernel.RBF_Kernel(par=par_best['par_kernel'])
            clf2 = NOLRE(kernel_rbf_train, loss_fun)
            clf2.training(X0_train, Y1_train, ep=0.01, reg_coefficient=par_best['par_reg'], n_echo=n_echo_train,
                          verbose=verbose,n_min_train_sample=n_min_train_sample)
            t3 = time.perf_counter()
            seconds_train = t3-t2
            # 2.2 prediction with the selected parameter values
            if flag_prediction:

                # on the training set
                y_pred_train = clf2.predicting(X0_train)
                metrics_train = get_metrics(Y1_train, y_pred_train)
                # on the test set
                y_pred_test = clf2.predicting(X0_test)
                metrics_test = get_metrics(Y0_test, y_pred_test)
                t4 = time.perf_counter()
                seconds_test = t4-t3
                seconds_train_test = t4-t2
                seconds_total = t4-t1
                if debug:
                    print('y_pred_test', y_pred_test)
                    print('y_true_test', Y0_test)
                print('metrics_train', metrics_train)
                print('metrics_test', metrics_test)
                print('elapsed_time ', seconds_train_test,seconds_total)

                # save the variables to the files
                best_params = gs.best_params_
                with open(result_file, 'wb') as f:
                    pickle.dump([metrics_train, metrics_test, seconds_train_test,seconds_total,
                                 y_pred_train, y_pred_test, Y1_train, Y0_test, par, name_data, loss_name, best_params,  file_name], f)

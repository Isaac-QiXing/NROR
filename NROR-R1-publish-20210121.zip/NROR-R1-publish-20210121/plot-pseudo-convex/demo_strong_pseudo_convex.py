# -*- coding: utf-8 -*-
# plot strong pseudo convex function 

 
from pynolre import loss
import pandas as pd
import math
import numpy as np
import random

#from numpy.linalg import cholesk
import matplotlib.pyplot as plt
from matplotlib.figure import figaspect
 

delta = 0.3  
ep = 0.15
lb = -0.5
ub = 0.5 
pred_value = np.linspace(lb,ub,num=1000)
x= pred_value
def cal_loss_vec(loss_obj,diff_v,ep):
#   calculate the losses 
    loss_v = np.zeros_like(diff_v)
    for ii,diff in enumerate(diff_v):
        loss_v[ii] =  loss_obj.loss_computing(pred_value=diff,true_value=0,ep=ep)
    return loss_v 

def cal_grad_vec(loss_obj,diff_v):
#   calculate the losses 
    grad_v = np.zeros_like(diff_v)
    for ii,diff in enumerate(diff_v):
        grad_v[ii] =  loss_obj.grad_computing(pred_value=diff,true_value=0,ep=ep)
    return grad_v 

diff_v = pred_value
loss1=loss.Canal(parameter = delta)
#loss01_v =  loss1.loss_computing(pred_value=pred_value,true_value=0,ep=ep)
loss01_v = cal_loss_vec(loss1,diff_v,ep=ep)
# grad01_v = cal_grad_vec(loss1,diff_v)

 

loss3=loss.Quadratic_insensitive( )
#loss03_v =  loss3.loss_computing(pred_value=pred_value,true_value=0,ep=ep)
loss03_v = cal_loss_vec(loss3,diff_v,ep=0)
#grad03_v = cal_grad_vec(loss3,diff_v)

 
flag = 1 # 1
fontsize= 12

if flag==1:
    # plot the loss functions 
    
    '''   plt.xlabel("t")
    plt.ylabel("y")
    plt.legend(bbox_to_anchor=(0,1.02,1,0.102),loc=0,ncol=2,mode="expand",borderaxespad=0)
    plt.show()'''

    w, h = figaspect(1/2.2)

    fig = plt.figure(figsize=(0.7*w,0.7*h))
    #fig = plt.figure()

    # plot the canal loss and the quadratic function 
    ax = fig.add_subplot(1,2,1)
    ax.plot(x,loss03_v,  label='Quadratic',color='tab:blue')
    ax.plot(x,loss01_v,  label='canal',color='tab:red')
    ax.set_xlabel('t',fontsize=fontsize-2)
    ax.set_ylabel('y',fontsize=fontsize-2)        
    #ax.xaxis.set_label_position("right") 
    ax.legend(loc = 'best',prop={'size':7}) # loc = 'best'
    #ax.set_title(title_subfig[i_dataset],y=-0.15)    
    ax.set_title('(A)',fontsize=fontsize,x= 0.95,y=-0.2)     
    # write the presentation of the function
    ax.text(-0.25,0.15,'$y=\ell_{canal}(t)$',color='tab:red')
    ax.text(-0.4,0.2,'$y= t^2$',color='tab:blue')
    #ax.set_aspect(4/1)
    #ax.set_aspect('equal')

    # plot the canal loss + quadratic function  
    ax = fig.add_subplot(1,2,2)
    #ax = fig.add_subplot(1,2,2,aspect='equal')
    #ax.plot(x,loss03_v,  label='Quadratic')
    #ax.plot(x,loss01_v+loss03_v,  label='Canal+Quadratic')
    ax.plot(x,loss01_v+loss03_v)
    ax.set_xlabel('t',fontsize=fontsize-2)
    ax.set_ylabel('y',fontsize=fontsize-2)        
    #ax.xaxis.set_label_position("right") 
    #ax.legend(loc='best',prop={'size':6}) # loc = 'best'
    #ax.set_title(title_subfig[i_dataset],y=-0.15)    
    ax.set_title('(B)',fontsize=fontsize,x= 0.95,y=-0.2)   
    # write the presentation of the function    
    ax.text(-0.35,0.3,'$y= \ell_{canal}(t) + t^2$',color='tab:blue')
    #ax.set_aspect('equal') # ax.set_aspect('auto')
    #ax.set_aspect(2/1)
 

    fig.tight_layout(pad=2.0)    
    figName = 'strong_pseudo_convex'  
    fig.savefig(figName +'.png',dpi = 600)
    plt.show()


 

 

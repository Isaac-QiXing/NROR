# main_print_results_f1_xls.py
# save the results of f1 to an  excel file  

#import common_excel as excel
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
import os


import xlrd
import xlwt
from xlutils.copy import copy

def write_excel_xls(path, sheet_name, value):
    index = len(value)  # 获取需要写入数据的行数
    workbook = xlwt.Workbook()  # 新建一个工作簿
    sheet = workbook.add_sheet(sheet_name)  # 在工作簿中新建一个表格
    for i in range(0, index):
        for j in range(0, len(value[i])):
            sheet.write(i, j, value[i][j])  # 像表格中写入数据（对应的行和列）
    workbook.save(path)  # 保存工作簿
    print("xls格式表格写入数据成功！")
 
 
def write_excel_xls_append(path, value):
    index = len(value)  # 获取需要写入数据的行数
    workbook = xlrd.open_workbook(path)  # 打开工作簿
    sheets = workbook.sheet_names()  # 获取工作簿中的所有表格
    worksheet = workbook.sheet_by_name(sheets[0])  # 获取工作簿中所有表格中的的第一个表格
    rows_old = worksheet.nrows  # 获取表格中已存在的数据的行数
    new_workbook = copy(workbook)  # 将xlrd对象拷贝转化为xlwt对象
    new_worksheet = new_workbook.get_sheet(0)  # 获取转化后工作簿中的第一个表格
    for i in range(0, index):
        for j in range(0, len(value[i])):
            new_worksheet.write(i+rows_old, j, value[i][j])  # 追加写入数据，注意是从i+rows_old行开始写入
    new_workbook.save(path)  # 保存工作簿
    print("xls格式表格【追加】写入数据成功！")

# parameters

debug_on = 1
flag_save2xls = 1  # whether save to excel files
flag_plot = 1  # whether plot the lines
flag_f1_only =1 
verbose =1

path_result = 'result_cv\\'
path_output = 'result\\' 

# Step 0.  select a analytic 'golden' regression function f
#f0 = fun_f1

if flag_f1_only: # merely test forester dataset
    fun_name_lt = ['f1']  # exclude 'powell',    
else:     
    name_data_lt = ['f1', 'WQ', 'EGSSD', 'Abalone',  'Cadata', 'Cpusmall', 'YearPred']


par_lt = [{'ratio_noise': 0,  'sigma_noise': 2.0},
              {'ratio_noise': 0.05, 'sigma_noise': 2.0},
              {'ratio_noise': 0.2, 'sigma_noise': 2.0},
              {'ratio_noise': 0.4, 'sigma_noise': 2.0},
              {'ratio_noise': 0.5, 'sigma_noise': 2.0},
              {'ratio_noise': 0.6, 'sigma_noise': 2.0}]
#loss_name_lt = ['NROR04', 'NROR08', 'Linear', 'Quadratic',  'Huber']  
loss_name_lt = ['NROR08', 'Linear', 'Quadratic',  'Huber']  
 # NROR04： delta = 0.4 for the canal loss 
 # NROR08： delta = 0.8 for the canal loss 
 
ind_par_ratio_noise = [0,1, 2, 3, 4,5]

n_fun = len(fun_name_lt) 
n_par = len(par_lt)
n_loss = len(loss_name_lt)

placeholder_char = '===='
# Step 1. load and reformulate the results of various  ratio_noise
result_ratio_noise = []
result_ratio_noise_plot = []
for i_fun in range(n_fun):
    # fun name
    fun_name = fun_name_lt[i_fun]
    name_data = fun_name
    ratio_noise_lt = []
    interval_len_dt = {}
    r1_lt = []
    r_inst_ratio_dt = {}
     
    for i_ind in range(len(ind_par_ratio_noise)):
        i_par = ind_par_ratio_noise[i_ind]

        for i_loss in range(n_loss):
            #  set the file name for saving the results            
            loss_name = loss_name_lt[i_loss]

            # Step 1.1. load the results
            # the file name for saving the results  
            if debug_on:
                print('---', name_data, '\t i_par: ', i_par, loss_name, '---')
            file_name = 'result_' + name_data + '_par_' + \
                str(i_par) + '_loss_' + loss_name + '.pkl'           

            result_file = path_result + file_name
            # load the variables
            with open(result_file, 'rb') as f:
                [metrics_train, metrics_test, seconds_train_test,seconds_total,
                    y_pred_train, y_pred_test, Y1_train, Y0_test, par, name_data, loss_name, 
                    best_params,  file_name] = pickle.load( f)

            # Step 1.2. re-organize the results for presentation          
            
            if i_loss == 1:
                ratio_noise = par['ratio_noise']
            else:
                ratio_noise = placeholder_char
            
            MAE = metrics_test['MAE']
            RMSE = metrics_test['RMSE']
            MAPE = metrics_test['MAPE']

            record0 = [ratio_noise, loss_name,  MAE, RMSE, MAPE, seconds_train_test]
            result_ratio_noise.append(record0)                    


if flag_save2xls:
    # 3.0 sheet names and title line
    book_name_ratio_xls = path_output + 'result_f1_test_set.xls'
     
    # sheet name for the two tables
    sheet_name_ratio = 'ratio_noise'    

    # title lines for the two tables
    value_title_ratio = [[  'r-noise', 'method',
                           "MAE","RMSE", "MAPE", "time (s)"]]
    
    # 3.1 print the results about ratio_noise to xls file
    '''excel.write_excel_xls(book_name_ratio_xls,
                          sheet_name_ratio, value_title_ratio)
    excel.write_excel_xls_append(
        book_name_ratio_xls, sheet_name_ratio, result_ratio_noise)'''

    write_excel_xls(book_name_ratio_xls,
                          sheet_name_ratio, value_title_ratio) 
    write_excel_xls_append(book_name_ratio_xls, result_ratio_noise)                      
    # excel.read_excel_xls(book_name_xls)
    print('finish to write. ')
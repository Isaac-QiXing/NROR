# main_readData.py
# read data from benchmark datasets 
import os,sys,pickle
import numpy as np
 
# import LibSVM 
pathBase = os.path.dirname(os.path.abspath(__file__))
pathLibSVM = pathBase + '\\libsvm-3-24\\python'
sys.path = [pathLibSVM] + sys.path
from  commonutil import svm_read_problem

# add path of pynolre
path_pynolre = pathBase + '\\pynolre'
sys.path = [path_pynolre] + sys.path



dataPath = pathBase + '\\dataset\\'
name_dataset_lt = [ 'WQ','EGSSD','Abalone','Cadata','Cpusmall','YearPred']  # datasets 
name_file_lt = [ 'WineQuality-White.txt','EGSSD.txt','abalone\\abalone_scale',
        'cadata\\cadata','cpusmall\\cpusmall_scale','YearPredictionMSD\\YearPredictionMSD.t']
type_data_lt =  [ 'txt','txt','svm','svm','svm','svm']

for i_data in range(len(name_dataset_lt)):
    name_data = name_dataset_lt[i_data]
    name_file = name_file_lt[i_data]
    type_data = type_data_lt[i_data]

    path_file = dataPath + name_file 
    output_file = dataPath + name_data + '.pkl'
    if type_data =='txt':        
        #xx=np.loadtxt("WineQuality-White.txt",usecols=(range(12)))
        X0 = np.loadtxt(path_file)
        n_sample,n_dim = X0.shape
        X = X0[:,0:n_dim-1]
        Y = X0[:,-1]
        n_dim = n_dim -1 
        
    elif type_data =='svm':      
        Y,X =     svm_read_problem(path_file,return_scipy = True)
        X=X.todense() # transfrom a sparse matrix to dense matrix      
        n_sample,n_dim = X.shape   
        #cadata_y,cadata_x = svm_read_problem(data_file_name, return_scipy=True)
    with open(output_file, 'wb') as f:                    
        pickle.dump([X,Y,n_sample,n_dim], f) 

    print(name_data,'X.shape',X.shape,'Y.shape',Y.shape)    
    print('X',X,'Y',Y)
